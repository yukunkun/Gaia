package com.gaiamount.module_charge.account_book;

/**
 * Created by haiyang-lu on 16-5-20.
 */
public class GetSpending {

}
