package com.gaiamount.widgets.media;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.SeekBar;
import android.widget.TextView;

import com.gaiamount.R;
import com.gaiamount.module_player.bean.VideoDetailInfo;
import com.gaiamount.util.LogUtil;
import com.gaiamount.util.ScreenUtils;

import java.util.Formatter;
import java.util.Locale;

/**
 * Created by haiyang-lu on 16-7-12.
 * gaiamount媒体控制栏控件
 */
public class GMediaController extends FrameLayout implements IGMediaController {
    private static final int sDefaultTimeout = 5000;
    private static final int FADE_OUT = 1;
    private static final int SHOW_PROGRESS = 2;
    private Context mContext;
    private Toolbar mToolbar;
    private TextView mCurrentTime;
    private SeekBar mProgress;
    private TextView mEndTime;
    private View mContentView;

    /**
     * 实现了该接口的实例
     */
    private GMediaPlayerControl mPlayer;
    private ImageView mIv_play;

    /**
     * 是否正在显示中
     */
    private boolean mShowing;
    /**
     * 是否正在拖动
     */
    private boolean mDragging;
    private StringBuilder mFormatBuilder;
    private Formatter mFormatter;
    private View mAnchor;
    private ImageView mIv_sound;
    private ImageView mIv_mask;
    private TextView mTv_definition;
    private ImageView mFullScreen;
    private AudioManager am;
    /**
     * 控制声音的seekbar
     */
    private SeekBar mSoundSeek;
    private final View mLightView;
    private SeekBar mLightSeek;

    public boolean isFullScreen() {
        return isFullScreen;
    }

    public GMediaController(Context context) {
        super(context);
        mContext = context;
        am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);

        LayoutInflater inflater = LayoutInflater.from(mContext);
        mSoundView = inflater.inflate(R.layout.item_player_sound, null);
        mDefinitionView = inflater.inflate(R.layout.item_player_definition, null);
        mMaskView = inflater.inflate(R.layout.item_player_mask, null);
        mLightView = inflater.inflate(R.layout.item_player_lightness, null);

    }

    private void initContentView(View root) {
        mCurrentTime = (TextView) root.findViewById(R.id.time_current);
        mProgress = (SeekBar) root.findViewById(R.id.mediacontroller_progress);
        mProgress.setMax(1000);
        mEndTime = (TextView) root.findViewById(R.id.tv_time);

        mIv_play = (ImageView) root.findViewById(R.id.play_btn);

        //只有全屏才显示的控件
        mIv_sound = (ImageView) root.findViewById(R.id.sound);
        mIv_mask = (ImageView) root.findViewById(R.id.mask);
        mTv_definition = (TextView) root.findViewById(R.id.definition);
        mFullScreen = (ImageView) root.findViewById(R.id.full_screen);

        //播放暂停
        if (mIv_play != null) {
            mIv_play.setOnClickListener(mPlayListener);
        }

        //全屏非全屏
        setFullScreenVisibility(false);
        mFullScreen.setOnClickListener(mFullScreenListener);

        //拖动进度条快进
        mProgress.setOnSeekBarChangeListener(mSeekBarChangeListener);

        //点击音量按钮显示音量调节控件（全屏）
        mIv_sound.setOnClickListener(mSoundListener);

        //点击显示遮罩选项
        mIv_mask.setOnClickListener(mMaskListener);

        //点击显示选择清晰度选项
        mTv_definition.setOnClickListener(mDefinitionListener);

        mFormatBuilder = new StringBuilder();
        mFormatter = new Formatter(mFormatBuilder, Locale.getDefault());

        initPopupWindowView();


    }

    private void initPopupWindowView() {
        //声音的popup～～～～
        mSoundSeek = (SeekBar) mSoundView.findViewById(R.id.soundSeek);
        mSoundSeek.setMax(am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));//android音量级数
        //设置为系统当前音量
        mSoundSeek.setProgress(am.getStreamVolume(AudioManager.STREAM_MUSIC));

        mSoundSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) {
                    return;
                }
                //根据progress的改变而改变音量
                am.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        //～～～～
        mLightView.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
        mLightSeek = (SeekBar) mLightView.findViewById(R.id.lightSeek);
        mLightSeek.setMax(1 * 100);
        LayoutParams params = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.CENTER_VERTICAL | Gravity.END;
        params.rightMargin = ScreenUtils.dp2Px(mContext, 80);
        mLightView.setLayoutParams(params);
        if (mAnchor instanceof ViewGroup) {
            ViewGroup anchor = (ViewGroup) mAnchor;
            anchor.removeView(mLightView);
            anchor.addView(mLightView);
            mLightView.setVisibility(View.GONE);
        }


    }

    public void showLightProgress() {
        if (mLightView != null) {
            mLightView.setVisibility(View.VISIBLE);
        }
    }

    public void hideLightProgress() {
        if (mLightView != null) {
            mLightView.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mLightView.setVisibility(View.GONE);
                }
            },2000);
        }
    }

    public void updateLightProgress(float light) {
        if (mLightSeek != null) {
            mLightSeek.setProgress((int) (light * 100));
        }
    }

    public void updateSoundProgress() {
        if (mSoundSeek != null) {
            //设置为系统当前音量
            mSoundSeek.setProgress(am.getStreamVolume(AudioManager.STREAM_MUSIC));
        }
    }

    private void updateDefinition() {
        //清晰度的popup
        FrameLayout definitonOrigin = (FrameLayout) mDefinitionView.findViewById(R.id.definitionOrigin);
        FrameLayout definition4K = (FrameLayout) mDefinitionView.findViewById(R.id.definition4K);
        FrameLayout definition2K = (FrameLayout) mDefinitionView.findViewById(R.id.definition2K);
        FrameLayout definition1080P = (FrameLayout) mDefinitionView.findViewById(R.id.definition1080P);
        FrameLayout definition720P = (FrameLayout) mDefinitionView.findViewById(R.id.definition720P);

        final String mp4 = mDetailInfo.getResource().getMp4();
        final String k4 = mDetailInfo.getResource().getK4();
        final String k2 = mDetailInfo.getResource().getK2();
        final String p1080 = mDetailInfo.getResource().getP1080();
        final String p720 = mDetailInfo.getResource().getP720();

        if (mDetailInfo != null) {
            //原画一定有
            definitonOrigin.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    //切换到原画
                    mPlayer.setVideoURI(Uri.parse(mp4));
                    mTv_definition.setText("原画");
                    dismissPopWindow();
                    updateSwitch();
                }
            });
            if (mDetailInfo.getWorks().getHave4K() == 1 && mDetailInfo.getResource().getK4() != null) {
                definition4K.setVisibility(View.VISIBLE);
                definition4K.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //切换到4k
                        mPlayer.setVideoURI(Uri.parse(k4));
                        mTv_definition.setText("4K");
                        dismissPopWindow();
                        updateSwitch();
                    }
                });
            } else {
                definition4K.setVisibility(View.GONE);

            }
            if (mDetailInfo.getWorks().getHave2K() == 1 && mDetailInfo.getResource().getK2() != null) {
                definition2K.setVisibility(View.VISIBLE);
                definition2K.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //切换到4k
                        mPlayer.setVideoURI(Uri.parse(k2));
                        mTv_definition.setText("2K");
                        dismissPopWindow();
                        updateSwitch();
                    }
                });
            } else {
                definition2K.setVisibility(View.GONE);
            }
            if (mDetailInfo.getWorks().getHave1080() == 1 && mDetailInfo.getResource().getP1080() != null) {
                definition1080P.setVisibility(View.VISIBLE);
                definition1080P.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //切换到4k
                        mPlayer.setVideoURI(Uri.parse(p1080));
                        mTv_definition.setText("1080P");
                        dismissPopWindow();
                        updateSwitch();
                    }
                });
            } else {
                definition1080P.setVisibility(mContentView.GONE);
            }
            if (mDetailInfo.getWorks().getHave720() == 1 && mDetailInfo.getResource().getP720() != null) {
                definition720P.setVisibility(View.VISIBLE);
                definition720P.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //切换到4k
                        mPlayer.setVideoURI(Uri.parse(p720));
                        mTv_definition.setText("720P");
                        updateSwitch();
                    }
                });
            } else {
                definition720P.setVisibility(View.GONE);
            }
        }
        //显示默认Uri的画质
        if (mDefaultUri != null) {
            if (mDefaultUri.equals(mp4)) {
                mTv_definition.setText("原画");
            } else if (mDefaultUri.equals(k4)) {
                mTv_definition.setText("4K");
            } else if (mDefaultUri.equals(k2)) {
                mTv_definition.setText("2K");
            } else if (mDefaultUri.equals(p1080)) {
                mTv_definition.setText("1080P");
            } else {
                mTv_definition.setText("720P");
            }
        }
    }

    private FrameLayout lastMaskLayout;

    private void updateMask() {
        final FrameLayout mask235 = (FrameLayout) mMaskView.findViewById(R.id.mask_2_35);
        final FrameLayout mask185 = (FrameLayout) mMaskView.findViewById(R.id.mask_1_85);
        final FrameLayout mask169 = (FrameLayout) mMaskView.findViewById(R.id.mask_16_9);
        final FrameLayout mask43 = (FrameLayout) mMaskView.findViewById(R.id.mask_4_3);
        mask235.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lastMaskLayout != null)
                    lastMaskLayout.setBackgroundColor(getResources().getColor(R.color.transparent));
                mPlayer.changeRenderSize(1);
                dismissPopWindow();
                mask235.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                lastMaskLayout = mask235;
            }
        });
        mask185.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lastMaskLayout != null)
                    lastMaskLayout.setBackgroundColor(getResources().getColor(R.color.transparent));
                mPlayer.changeRenderSize(2);
                dismissPopWindow();
                mask185.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                lastMaskLayout = mask185;
            }
        });
        mask169.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lastMaskLayout != null)
                    lastMaskLayout.setBackgroundColor(getResources().getColor(R.color.transparent));
                mPlayer.changeRenderSize(3);
                dismissPopWindow();
                mask169.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                lastMaskLayout = mask169;
            }
        });
        mask43.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lastMaskLayout != null)
                    lastMaskLayout.setBackgroundColor(getResources().getColor(R.color.transparent));
                mPlayer.changeRenderSize(4);
                dismissPopWindow();
                mask43.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                lastMaskLayout = mask43;
            }
        });

    }

    private void updateSwitch() {
        if (isFullScreen) {
            if (mFullScreen != null) {
                mFullScreen.setImageResource(R.mipmap.ic_collapse_n);
                setFullScreenVisibility(true);
            }
        } else {
            if (mFullScreen != null) {
                mFullScreen.setImageResource(R.mipmap.ic_fullscreen);
                setFullScreenVisibility(false);
            }
        }
    }

    public void setFullScreenVisibility(boolean visibility) {
        if (visibility) {
            mIv_sound.setVisibility(View.VISIBLE);
            mIv_mask.setVisibility(View.VISIBLE);
            mTv_definition.setVisibility(View.VISIBLE);
        } else {
            mIv_sound.setVisibility(View.GONE);
            mIv_mask.setVisibility(View.GONE);
            mTv_definition.setVisibility(View.GONE);
        }
    }


    // This is called whenever mAnchor's layout bound changes
    private final OnLayoutChangeListener mLayoutChangeListener =
            new OnLayoutChangeListener() {
                @Override
                public void onLayoutChange(View v, int left, int top, int right,
                                           int bottom, int oldLeft, int oldTop, int oldRight,
                                           int oldBottom) {

                }
            };

    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            int pos;
            switch (msg.what) {
                case FADE_OUT:
                    hide();
                    break;
                case SHOW_PROGRESS:
                    pos = setProgress();
                    if (!mDragging && mShowing && mPlayer.isPlaying()) {
                        msg = obtainMessage(SHOW_PROGRESS);
                        sendMessageDelayed(msg, 1000 - (pos % 1000));
                    }
                    break;
            }
        }
    };

    private int setProgress() {
        if (mPlayer == null || mDragging) {
            return 0;
        }
        int position = mPlayer.getCurrentPosition();
        int duration = mPlayer.getDuration();

        if (mProgress != null) {
            if (duration > 0) {
                long pos = 1000L * position / duration;
                mProgress.setProgress((int) pos);
            }
            int percent = mPlayer.getBufferPercentage();
            mProgress.setSecondaryProgress(percent * 10);
        }

        if (mCurrentTime != null) {
            mCurrentTime.setText(stringForTime((int) position));
        }
        if (mEndTime != null) {
            mEndTime.setText(stringForTime((int) duration));
        }

        return 0;
    }

    private String stringForTime(int timeMs) {
        int totalSeconds = timeMs / 1000;
        int seconds = totalSeconds % 60;
        int minutes = (totalSeconds / 60) % 60;
        int hours = totalSeconds / 3600;

        mFormatBuilder.setLength(0);

        if (hours > 0) {
            return mFormatter.format("%d:%02d:%02d", hours, minutes, seconds).toString();
        } else {
            return mFormatter.format("%02d:%02d", minutes, seconds).toString();
        }

    }

    @Override
    public void hide() {
        updatePausePlay();
        if (mShowing) {
            mHandler.removeMessages(SHOW_PROGRESS);
            if (mAnchor instanceof ViewGroup) {
                ViewGroup anchor = (ViewGroup) mAnchor;
                anchor.removeView(this);
            }
        }

        if (mToolbar != null) {
            mToolbar.setVisibility(View.GONE);
        }
        dismissPopWindow();
        mShowing = false;
    }

    @Override
    public void show(int timeout) {
        updatePausePlay();
        if (!mShowing) {
            mHandler.sendEmptyMessage(SHOW_PROGRESS);

            if (mAnchor instanceof ViewGroup) {
                ViewGroup anchor = (ViewGroup) mAnchor;
                LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
                params.gravity = Gravity.BOTTOM;
                anchor.addView(this, params);
            }
            mShowing = true;
        }

        if (timeout != 0) {
            mHandler.removeMessages(FADE_OUT);
            Message message = mHandler.obtainMessage(FADE_OUT);
            mHandler.sendMessageDelayed(message, timeout);
        }

        if (mToolbar != null) {
            mToolbar.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void show() {
        show(sDefaultTimeout);
    }

    @Override
    public boolean isShowing() {
        return mShowing;
    }

    @Override
    public void setAnchorView(View view) {
        if (mAnchor != null) {
            mAnchor.removeOnLayoutChangeListener(mLayoutChangeListener);
        }
        mAnchor = view;
        if (mAnchor != null) {
            mAnchor.addOnLayoutChangeListener(mLayoutChangeListener);
        }

        //点击事件
        if (mAnchor != null) {
            mAnchor.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isShowing()) {
                        hide();
                    } else {
                        show();
                    }
                }
            });

        }
        FrameLayout.LayoutParams frameParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        );
        removeAllViews();
        View v = makeControllerView();
        addView(v, frameParams);


    }

    private void dismissPopWindow() {
        if (mPopupSound != null && mPopupSound.isShowing()) {
            mPopupSound.dismiss();
        }
        if (mPopupMask != null && mPopupMask.isShowing()) {
            mPopupMask.dismiss();
        }
        if (mPopupDefinition != null && mPopupDefinition.isShowing()) {
            mPopupDefinition.dismiss();
        }
    }

    private View makeControllerView() {
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mContentView = inflater.inflate(R.layout.media_controller, null);

        initContentView(mContentView);

        return mContentView;
    }

    @Override
    public void showOnce(View view) {

    }

    @Override
    public void setMediaPlayer(GMediaPlayerControl player) {
        mPlayer = player;
        updatePausePlay();

    }

    @Override
    public void setToolbar(Toolbar toolbar) {
        mToolbar = toolbar;
        if (isShowing()) {
            mToolbar.setVisibility(View.VISIBLE);
        } else {
            mToolbar.setVisibility(View.GONE);
        }
    }

    @Override
    public void updateScreen() {
        updatePausePlay();
    }

    private final OnClickListener mPlayListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            //播放或暂停
            doPauseResume();
            show(sDefaultTimeout);
        }
    };

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~萌萌的分割线～～～
    private PopupWindow mPopupDefinition;
    private View mDefinitionView;
    private final OnClickListener mDefinitionListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            //如果有其他显示的，先dismiss掉
            dismissPopWindow();
            if (mPopupDefinition == null) {
                mPopupDefinition = new PopupWindow(mDefinitionView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                mPopupDefinition.setBackgroundDrawable(getResources().getDrawable(R.color.black60));
            }
            mDefinitionView.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
            int height = mDefinitionView.getMeasuredHeight();
            setPopupWindow(mPopupDefinition, mTv_definition, -ScreenUtils.dp2Px(mContext, 50), -height - ScreenUtils.dp2Px(mContext, 40));
        }
    };

    //遮罩
    private PopupWindow mPopupMask;
    private View mMaskView;
    private final OnClickListener mMaskListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            //如果有其他显示的，先dismiss掉
            dismissPopWindow();
            if (mPopupMask == null) {
                mPopupMask = new PopupWindow(mMaskView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                mPopupMask.setBackgroundDrawable(getResources().getDrawable(R.color.black60));
            }
            mMaskView.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
            int height = mMaskView.getMeasuredHeight();
            setPopupWindow(mPopupMask, mIv_mask, -ScreenUtils.dp2Px(mContext, 50), -height - ScreenUtils.dp2Px(mContext, 40));
        }
    };

    //声音按钮
    private PopupWindow mPopupSound;
    private View mSoundView;
    private final OnClickListener mSoundListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            //如果有其他显示的，先dismiss掉
            dismissPopWindow();
            if (mPopupSound == null) {
                mPopupSound = new PopupWindow(mSoundView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                mPopupSound.setBackgroundDrawable(getResources().getDrawable(R.color.black60));
            }
            mSoundView.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
            int height = mSoundView.getMeasuredHeight();
            LogUtil.w(GMediaPlayerControl.class, "measuredHeight:" + height);
            setPopupWindow(mPopupSound, mIv_sound, ScreenUtils.dp2Px(mContext, 10), -height - ScreenUtils.dp2Px(mContext, 40));

        }
    };

    public void setPopupWindow(PopupWindow popupWindow, View view, int offsetX, int offsetY) {
        //在其上方显示控件
        if (popupWindow != null && popupWindow.isShowing()) {
            popupWindow.dismiss();
        } else {
            LogUtil.d(GMediaPlayerControl.class, "offsetX:" + offsetX + ",offsetY:" + offsetY);
            popupWindow.showAsDropDown(view, offsetX, offsetY);
        }
    }

    //进度条改变
    private SeekBar.OnSeekBarChangeListener mSeekBarChangeListener = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            if (!fromUser) {
                return;
            }
            long duration = mPlayer.getDuration();
            long newPos = duration * progress / 1000L;
            mPlayer.seekTo((int) newPos);
            if (mCurrentTime != null)
                mCurrentTime.setText(stringForTime((int) newPos));
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
            //长时间显示控制栏
            show(1000 * 1000);
            mDragging = true;
            //移除定时更新进度的消息
            mHandler.removeMessages(SHOW_PROGRESS);
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            //恢复默认时间
            show(sDefaultTimeout);
            mDragging = false;
            //恢复定时更新进度的消息
            mHandler.sendEmptyMessage(SHOW_PROGRESS);
        }
    };

    private boolean isFullScreen;
    private final OnClickListener mFullScreenListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            isFullScreen = !isFullScreen;
            //全屏或非全屏
            if (isFullScreen) {
                switchLand();


            } else {
                switchPortrait();

            }
            updateSwitch(isFullScreen);
        }
    };

    public void switchPortrait() {
        //全屏
        if (mContext instanceof Activity) {
            Activity activity = (Activity) mContext;
            activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) mAnchor.getLayoutParams();
            lp.width = LayoutParams.MATCH_PARENT;
            lp.height = LayoutParams.WRAP_CONTENT;
            mAnchor.setLayoutParams(lp);
        }
    }

    public void switchLand() {

        //竖屏
        if (mContext instanceof Activity) {
            Activity activity = (Activity) mContext;
            activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) mAnchor.getLayoutParams();
            lp.width = LayoutParams.MATCH_PARENT;
            lp.height = LayoutParams.MATCH_PARENT;
            mAnchor.setLayoutParams(lp);
        }
    }

    public void updateSwitch(boolean isLand) {
        this.isFullScreen = isLand;
        updateSwitch();
    }

    private boolean isPaused = false;

    private void doPauseResume() {
        if (mPlayer.isPlaying()) {
            mPlayer.pause();
            isPaused = true;
        } else {
            mPlayer.start();
            isPaused = false;
        }
        updatePausePlay();
    }

    public void updatePausePlay() {
        if (mIv_play == null) {
            return;
        }
        if (!isPaused || mPlayer.isPlaying()) {
            mIv_play.setImageResource(R.mipmap.ic_pause);
        } else {
            mIv_play.setImageResource(R.mipmap.ic_player);
        }
    }

    VideoDetailInfo mDetailInfo;

    public void setVideoInfo(VideoDetailInfo detailInfo) {
        if (detailInfo == null) {
            return;
        }
        this.mDetailInfo = detailInfo;

        updateDefinition();

        updateMask();
    }

    String mDefaultUri;

    public void setDefaultUri(String defaultUri) {
        this.mDefaultUri = defaultUri;
    }

    public interface GMediaPlayerControl {
        void start();

        void pause();

        int getDuration();

        int getCurrentPosition();

        void seekTo(int pos);

        boolean isPlaying();

        int getBufferPercentage();

        boolean canPause();

        boolean canSeekBackward();

        boolean canSeekForward();

        /**
         * Get the audio session id for the player used by this VideoView. This can be used to
         * apply audio effects to the audio track of a video.
         *
         * @return The audio session, or 0 if there was an error.
         */
        int getAudioSessionId();

        void setVideoURI(Uri uri);

        void changeRenderSize(int index);
    }

    public void stop() {
        mHandler.removeCallbacksAndMessages(null);
    }

}
