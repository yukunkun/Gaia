package com.gaiamount.module_creator.sub_module_album;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.gaiamount.R;
import com.gaiamount.apis.api_creator.AlbumApiHelper;
import com.gaiamount.gaia_main.GaiaApp;
import com.gaiamount.module_creator.dialog.AlbumPwdValidateDialog;
import com.gaiamount.util.image.ImageUtils;
import com.gaiamount.util.network.GsonUtil;
import com.gaiamount.util.network.MJsonHttpResponseHandler;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 专辑详情 包括专辑的封面等信息，专辑的作品
 * 作品类型{@link AlbumCreationType}
 */
public class AlbumDetailActivity extends AppCompatActivity implements AlbumPwdValidateDialog.OnContactWithActivity {

    public static final String AID = "aid";
    public static final String ALBUM_TYPE = "album_type";
    public static final String IS_PUBLIC = "is_public";
    public static final String IS_JOIN = "is_join";
    public static final String HAVE_POWER = "have_power";
    public static final String GID = "gid";

    @Bind(R.id.title)
    TextView mTV_Title;
    /**
     * toolbar控件
     */
    @Bind(R.id.toolbar)
    Toolbar mToolbar;
    /**
     * 专辑封面
     */
    @Bind(R.id.album_cover)
    ImageView mIV_AlbumCover;
    /**
     * 专辑描述
     */
    @Bind(R.id.album_desc)
    TextView mTV_AlbumDesc;
    /**
     * tabLayout控件
     */
    @Bind(R.id.tab_layout)
    TabLayout mTabLayout;
    /**
     * 分页控件
     */
    @Bind(R.id.view_pager)
    ViewPager mViewPager;


    /**
     * 专辑id
     */
    private long mAid;
    /**
     * 专辑类型，有小组或者个人
     */
    private int mAlbumType;
    /**
     * 是否公开,如果是加密视频，费小组成员需要输入密码才能访问
     */
    private int mIsPublic;
    /**
     * 当前访问者是否是小组成员
     */
    private int mIsJoin;
    private int mHavePower;
    private long mGid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album_detail);
        ButterKnife.bind(this);

        mAid = getIntent().getLongExtra(AID, -1);
        mAlbumType = getIntent().getIntExtra(ALBUM_TYPE, -1);
        mIsPublic = getIntent().getIntExtra(IS_PUBLIC, -1);
        mIsJoin = getIntent().getIntExtra(IS_JOIN, -1);
        mHavePower = getIntent().getIntExtra(HAVE_POWER, -1);
        mGid = getIntent().getLongExtra(GID,-1);

        setToolbar();

        if (mIsPublic == 0 && mIsJoin == 0) {//加密且非小组成员
            //弹出对话框
            AlbumPwdValidateDialog albumPwdValidateDialog = AlbumPwdValidateDialog.newInstance(mAid);
            albumPwdValidateDialog.show(getSupportFragmentManager(), "album_pwd");
            albumPwdValidateDialog.setOnContactWithActivity(this);

        } else {
            getDetails(null);
        }
    }

    public void prepareFragments() {
        //准备fragment
        List<Fragment> fragmentList = new ArrayList<>();
        fragmentList.add(AlbumWorkFrag.newInstance(mAid, mAlbumType,mGid, AlbumCreationType.WORK));
        fragmentList.add(AlbumMaterialFrag.newInstance(mAid, mAlbumType, AlbumCreationType.WORK));
        fragmentList.add(AlbumScriptFrag.newInstance(mAid, mAlbumType, AlbumCreationType.WORK));
        fragmentList.add(AlbumCollageFrag.newInstance(mAid, mAlbumType, AlbumCreationType.WORK));
        mViewPager.setAdapter(new MAdapter(getSupportFragmentManager(), fragmentList));
        //关联
        mTabLayout.setupWithViewPager(mViewPager);
    }

    public int isHavePower() {
        return mHavePower;
    }


    /**
     * 设置toolbar事件
     */
    private void setToolbar() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        if (mHavePower == 1) {
            mToolbar.inflateMenu(R.menu.album_detail);
        } else {
            mToolbar.inflateMenu(R.menu.share);
        }
        mToolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.action_delete_album) {
                    //删除专辑
                    MJsonHttpResponseHandler handler = new MJsonHttpResponseHandler(AlbumDetailActivity.class){
                        @Override
                        public void onGoodResponse(JSONObject response) {
                            super.onGoodResponse(response);
                            GaiaApp.showToast("专辑已删除");
                            finish();
                        }
                    };
                    AlbumApiHelper.deleteAlbum(mAid,AlbumDetailActivity.this,handler);
                } else if (id == R.id.action_share_album) {
                    // TODO: 16-6-30 分享专辑
                }
                return true;
            }
        });
    }

    /**
     * @param pi
     * @param ps
     * @param handler
     */
    public void getAlbumWorks(int c, int pi, int ps, MJsonHttpResponseHandler handler) {
        AlbumApiHelper.searchAlbumWorks(mAid,1,c,0,0,1,100,this,handler);
//        AlbumApiHelper.searchAlbumWorks(49, 1, c, 0, 0, 1, 100, this, handler);
    }

    @Override
    public void onOKButtonClicked(final DialogFragment dialogFragment, String pwd) {
        getDetails(pwd);
        dialogFragment.dismiss();
    }

    private void getDetails(String pwd) {
        //验证密码是否正确，同时如果正确，返回专辑详情
        MJsonHttpResponseHandler handler = new MJsonHttpResponseHandler(AlbumDetailActivity.class) {
            @Override
            public void onGoodResponse(JSONObject response) {
                super.onGoodResponse(response);
                JSONObject a = response.optJSONObject("a");
                AlbumDetail albumDetail = GsonUtil.getInstannce().getGson().fromJson(a.toString(), AlbumDetail.class);
                setUpView(albumDetail);
                prepareFragments();
            }

            @Override
            public void onBadResponse(JSONObject response) {
                super.onBadResponse(response);

            }
        };
        AlbumApiHelper.getAlbumDetail(mAid, pwd, AlbumDetailActivity.this, handler);
    }

    /**
     * 填充视图数据
     *
     * @param albumDetail
     */
    private void setUpView(AlbumDetail albumDetail) {
        //专辑名称
        mTV_Title.setText(albumDetail.getName());
        //专辑图片
        ImageUtils.getInstance(AlbumDetailActivity.this).getCover(mIV_AlbumCover, albumDetail.getBgImg());
        //专辑描述
        mTV_AlbumDesc.setText(albumDetail.getContent());

    }


    class MAdapter extends FragmentStatePagerAdapter {

        private String[] mStrings;
        private List<Fragment> mFragmentList;

        public MAdapter(FragmentManager fm, List<Fragment> fragmentList) {
            super(fm);
            mFragmentList = fragmentList;
            mStrings = getResources().getStringArray(R.array.album_type);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mStrings[position];
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mStrings.length;
        }
    }
}
