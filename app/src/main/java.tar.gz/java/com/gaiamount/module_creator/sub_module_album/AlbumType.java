package com.gaiamount.module_creator.sub_module_album;

/**
 * Created by haiyang-lu on 16-7-1.
 */
public class AlbumType {
    public static int TYPE_PERSONAL = 0;

    public static int TYPE_GROUP = 1;
}
