package com.gaiamount.module_creator.sub_module_group.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RadioButton;

import com.gaiamount.R;
import com.gaiamount.module_creator.sub_module_group.activities.GroupEditActivity;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by haiyang-lu on 16-6-16.
 */
public class SetGroupRequireExamine extends Fragment {

    @Bind(R.id.set_group_need_examine)
    RadioButton mSetGroupNeedExamine;
    @Bind(R.id.set_group_not_need_examine)
    RadioButton mSetGroupNotNeedExamine;
    private GroupEditActivity mHostActivity;

    private int isExamine;

    public static SetGroupRequireExamine newInstance() {
        SetGroupRequireExamine setGroupDescFrag = new SetGroupRequireExamine();
        return setGroupDescFrag;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof GroupEditActivity) {
            mHostActivity = (GroupEditActivity) context;
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_set_group_examine, container, false);
        ButterKnife.bind(this, view);


        mSetGroupNeedExamine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSetGroupNeedExamine.setChecked(true);
                isExamine = 1;

            }
        });
        mSetGroupNotNeedExamine.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                mSetGroupNotNeedExamine.setChecked(true);
                isExamine = 0;
            }
        });

        return view;
    }

    private void finishSelf() {
        FragmentManager supportFragmentManager = mHostActivity.getSupportFragmentManager();
        supportFragmentManager.beginTransaction().detach(SetGroupRequireExamine.this).commit();
        supportFragmentManager.popBackStack();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_finish, menu);
        super.onCreateOptionsMenu(menu, inflater);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_finish) {
            //设置审核
            mHostActivity.setExamination(isExamine);
            finishSelf();
        }
        return super.onOptionsItemSelected(item);

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }
}
