package com.gaiamount.module_creator.sub_module_group.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.gaiamount.R;
import com.gaiamount.module_creator.beans.GroupDetailInfo;

import butterknife.Bind;
import butterknife.ButterKnife;

public class GroupMoreActivity extends AppCompatActivity {

    public static final String GROUP_DETAIL_INFO = "group_detail_info";
    @Bind(R.id.toolbar)
    Toolbar mToolbar;
    @Bind(R.id.group_more_detail_keywords)
    TextView mGroupMoreDetailKeywords;
    @Bind(R.id.group_more_detail_desc)
    TextView mGroupMoreDetailDesc;

    private GroupDetailInfo mGroupDetailInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_more);
        ButterKnife.bind(this);

        mGroupDetailInfo = (GroupDetailInfo) getIntent().getSerializableExtra(GROUP_DETAIL_INFO);

        mGroupMoreDetailKeywords.setText(mGroupDetailInfo.getO().getGroup().getKeywords());

        mGroupMoreDetailDesc.setText(mGroupDetailInfo.getO().getGroup().getDescription());

        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
