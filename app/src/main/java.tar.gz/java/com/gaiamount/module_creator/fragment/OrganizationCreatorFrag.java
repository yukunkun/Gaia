package com.gaiamount.module_creator.fragment;

/**
 * Created by haiyang-lu on 16-6-6.
 */
public class OrganizationCreatorFrag extends CreatorBaseFrag {
    @Override
    public String getFragmentTitle() {
        return "机构";
    }

    public static OrganizationCreatorFrag newInstance() {
        return new OrganizationCreatorFrag();
    }
}
