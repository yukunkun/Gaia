package com.gaiamount.module_creator.sub_module_album;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gaiamount.R;
import com.gaiamount.apis.api_creator.AlbumApiHelper;
import com.gaiamount.util.image.ImageUtils;
import com.gaiamount.util.network.GsonUtil;
import com.gaiamount.util.network.MJsonHttpResponseHandler;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * 1显示专辑列表
 * 2创建专辑
 */
public class AlbumListActivity extends AppCompatActivity {

    public static final String GID = "gid";
    public static final String ALBUM_TYPE = "album_type";
    public static final String HAVE_POWER = "have_power";
    public static final String IS_JOIN = "is_join";
    private static final int CREATE_ALBUM = 23;
    private static final int ALBUM_DETAIL = 24;
    /**
     * toolbar控件
     */
    @Bind(R.id.toolbar)
    Toolbar mToolbar;
    @Bind(R.id.title)
    TextView mTv_Title;
    /**
     * 专辑列表控件
     */
    @Bind(R.id.album_list)
    RecyclerView mAlbumList;
    /**
     * 内容为空的提示
     */
    @Bind(R.id.empty_hint)
    RelativeLayout emptyHint;
    /**
     * 小组id，从传入intent中获取
     */
    private long mGid;
    private int mAlbumType;
    private int mHavePower;
    /**
     * 当前用户是否加入了该专辑所在小组
     */
    private int mIsJoin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album_list);
        ButterKnife.bind(this);

        mGid = getIntent().getLongExtra(GID, -1);
        mAlbumType = getIntent().getIntExtra(ALBUM_TYPE, -1);
        mHavePower = getIntent().getIntExtra(HAVE_POWER, -1);
        mIsJoin = getIntent().getIntExtra(IS_JOIN, -1);

        setToolbar();

        //联网获取专辑列表数据
        getAlbumListFromNet();
    }

    /**
     * 联网获取专辑列表数据
     */
    private void getAlbumListFromNet() {
        MJsonHttpResponseHandler handler = new MJsonHttpResponseHandler(AlbumListActivity.class) {
            @Override
            public void onGoodResponse(JSONObject response) {
                super.onGoodResponse(response);
                JSONArray jsonArray = response.optJSONArray("a");
                mTv_Title.setText("专辑" + "(" + jsonArray.length() + ")");
                if (jsonArray.length() == 0) {
                    //显示提示
                    emptyHint.setVisibility(View.VISIBLE);
                } else {
                    emptyHint.setVisibility(View.GONE);
                }
                List<AlbumBean> list = GsonUtil.getInstannce().getGson().fromJson(jsonArray.toString(), new TypeToken<List<AlbumBean>>() {
                }.getType());

                mAlbumList.setLayoutManager(new LinearLayoutManager(AlbumListActivity.this));
                mAlbumList.setAdapter(new MAdapter(list));

            }
        };
        AlbumApiHelper.getAlbumList(mGid, mAlbumType, 1, this, handler);
    }

    /**
     * toolbar事件处理
     */
    private void setToolbar() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //只有有权限的人才能创建专辑
        if (mHavePower == 1) {
            mToolbar.inflateMenu(R.menu.album_list);
        }
        mToolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.action_add_album) {
                    Intent intent = new Intent(AlbumListActivity.this, SetUpAlbumActivity.class);
                    intent.putExtra(SetUpAlbumActivity.GID, mGid);
                    intent.putExtra(SetUpAlbumActivity.ALBUM_TYPE, mAlbumType);
                    startActivityForResult(intent, CREATE_ALBUM);
                }
                return true;
            }
        });
    }


    class MAdapter extends RecyclerView.Adapter<MViewHolder> {


        private List<AlbumBean> mList;
        private final ImageUtils mImageUtils;

        public MAdapter(List<AlbumBean> list) {

            mList = list;
            mImageUtils = ImageUtils.getInstance(AlbumListActivity.this);

        }

        @Override
        public MViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = View.inflate(AlbumListActivity.this, R.layout.item_album_list, null);
            MViewHolder holder = new MViewHolder(itemView);
            return holder;
        }

        @Override
        public void onBindViewHolder(MViewHolder holder, int position) {
            final AlbumBean albumBean = mList.get(position);
            //专辑封面
            mImageUtils.getCover(holder.albumCover, albumBean.getCover());
            //专辑信息
            holder.albumInfo.setText("作品 " + albumBean.getWorksCount() + "|" +
                    "素材 " + albumBean.getMaterialCount() + "|" +
                    "剧本 " + albumBean.getScriptCount() + "|" +
                    "学院 " + albumBean.getCollegeCount());
            //专辑标题
            holder.albumTitle.setText(albumBean.getName());
            //点击封面跳转到专辑详情
            holder.albumCover.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(AlbumListActivity.this, AlbumDetailActivity.class);
                    intent.putExtra(AlbumDetailActivity.AID, albumBean.getAid());
                    intent.putExtra(AlbumDetailActivity.ALBUM_TYPE, mAlbumType);
                    intent.putExtra(AlbumDetailActivity.IS_PUBLIC, albumBean.getIsPublic());
                    intent.putExtra(AlbumDetailActivity.IS_JOIN, mIsJoin);
                    intent.putExtra(AlbumDetailActivity.HAVE_POWER, mHavePower);
                    intent.putExtra(AlbumDetailActivity.GID, mGid);
                    startActivityForResult(intent, ALBUM_DETAIL);
                }
            });
        }


        @Override
        public int getItemCount() {
            return mList.size();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ALBUM_DETAIL || requestCode == CREATE_ALBUM && resultCode == RESULT_OK) {
            //刷新
            getAlbumListFromNet();
        }
    }

    class MViewHolder extends RecyclerView.ViewHolder {
        private TextView albumInfo;
        private TextView albumTitle;
        private ImageView albumCover;

        public MViewHolder(View itemView) {
            super(itemView);
            albumCover = (ImageView) itemView.findViewById(R.id.album_cover);
            albumInfo = (TextView) itemView.findViewById(R.id.album_info);
            albumTitle = (TextView) itemView.findViewById(R.id.album_title);
        }
    }


}
