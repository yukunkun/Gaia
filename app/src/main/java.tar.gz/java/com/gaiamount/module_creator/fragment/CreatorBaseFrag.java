package com.gaiamount.module_creator.fragment;

import android.support.v4.app.Fragment;

/**
 * Created by haiyang-lu on 16-6-6.
 */
public abstract class CreatorBaseFrag extends Fragment {

    public abstract String getFragmentTitle();
}
