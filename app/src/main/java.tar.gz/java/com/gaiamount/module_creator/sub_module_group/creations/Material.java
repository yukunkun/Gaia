package com.gaiamount.module_creator.sub_module_group.creations;

import android.os.Bundle;
import android.support.v4.app.Fragment;

/**
 * Created by haiyang-lu on 16-6-27.
 */
public class Material extends Fragment {

    public static Material newInstance(long gid) {

        Bundle args = new Bundle();

        Material fragment = new Material();
        fragment.setArguments(args);
        return fragment;
    }
}
