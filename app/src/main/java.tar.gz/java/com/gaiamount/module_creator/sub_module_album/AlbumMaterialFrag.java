package com.gaiamount.module_creator.sub_module_album;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;

/**
 * Created by haiyang-lu on 16-6-30.
 */
public class AlbumMaterialFrag extends Fragment {
    public static final String AID = "aid";
    public static final String ALBUM_TYPE = "albumType";
    public static final String C = "c";
    private long mAid;
    private int mAlbumType;
    private int mC;

    public static AlbumMaterialFrag newInstance(long aid, int t, int c) {

        Bundle args = new Bundle();
        args.putLong(AID, aid);
        args.putInt(ALBUM_TYPE,t);
        args.putInt(C,c);
        AlbumMaterialFrag fragment = new AlbumMaterialFrag();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        mAid = args.getLong(AID);
        mAlbumType = args.getInt(ALBUM_TYPE);
        mC = args.getInt(C);
    }
}
