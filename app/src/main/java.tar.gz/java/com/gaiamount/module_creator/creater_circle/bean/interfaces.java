package com.gaiamount.module_creator.creater_circle.bean;

/**
 * Created by yukun on 16-7-5.
 */
public class interfaces {
    public interface SetOnItemClickListener{
        public void onItemClick(int position);
    }
}
