package com.gaiamount.module_creator.sub_module_group.creations;

import android.os.Bundle;
import android.support.v4.app.Fragment;

/**
 * Created by haiyang-lu on 16-6-27.
 */
public class Script extends Fragment {
    public static Script newInstance(long gid) {

        Bundle args = new Bundle();

        Script fragment = new Script();
        fragment.setArguments(args);
        return fragment;
    }
}
