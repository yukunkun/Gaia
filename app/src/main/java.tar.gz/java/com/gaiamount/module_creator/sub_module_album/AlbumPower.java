package com.gaiamount.module_creator.sub_module_album;

/**
 * Created by haiyang-lu on 16-7-1.
 */
public class AlbumPower {
    public static int PUBLIC = 1;

    public static int PRIVATE = 0;
}
