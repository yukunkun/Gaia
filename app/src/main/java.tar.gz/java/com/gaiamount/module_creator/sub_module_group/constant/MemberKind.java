package com.gaiamount.module_creator.sub_module_group.constant;

/**
 * Created by haiyang-lu on 16-7-1.
 */
public class MemberKind {
    public static int VISITOR = 0;

    public static int NORMAL = 1;

    public static int ADMIN = 2;

    public static int MONITOR = 3;
}
