package com.gaiamount.module_creator.sub_module_group.constant;

/**
 * Created by haiyang-lu on 16-7-5.
 */
public class CreationType {
    public static int TYPE_WORK = 0;

    public static int TYPE_METERIAL = 1;

    public static int TYPE_COLLAGE = 2;

    public static int TYPE_SCRIPTE = 3;

}
