package com.gaiamount.module_im.secret_chat.activity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.gaiamount.R;
import com.gaiamount.gaia_main.GaiaApp;
import com.gaiamount.module_creator.sub_module_group.activities.GroupMemberActivity;
import com.gaiamount.module_im.secret_chat.adapter.ChatAdapter;
import com.gaiamount.module_im.secret_chat.bean.ContentInfo;
import com.gaiamount.module_im.secret_chat.model.MessageEvent;
import com.gaiamount.module_im.secret_chat.model.OnEventNew;
import com.gaiamount.util.ActivityUtil;
import com.hyphenate.EMCallBack;
import com.hyphenate.EMMessageListener;
import com.hyphenate.chat.EMClient;
import com.hyphenate.chat.EMConversation;
import com.hyphenate.chat.EMImageMessageBody;
import com.hyphenate.chat.EMMessage;
import com.hyphenate.chat.EMMessageBody;
import com.hyphenate.chat.EMTextMessageBody;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * kun
 */
public class GroupChatActivity extends AppCompatActivity {
    private EMMessageListener msgListener;
    private String imid;
    private String otherAvatar;
    private String otherNickName;
    private EditText mEditText;
    private ListView mListView;
    ChatAdapter chatAdapter;
    int PHOTO_FROM_MAP=0;
    int TAKE_PICTURE=1;
    private String from="";
    private String groupId;
    ArrayList<ContentInfo> contentInfos=new ArrayList<>();
    private TextView mTextViewTitle;
    private List<EMMessage> messages;
    private TextView photoFromMap,photoFromCarmer,photoQuit;
    private PopupWindow popupWindow;
    private List<EMMessage> msgs=new ArrayList<>();
    protected Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            handler.post(new Runnable() {
                @Override
                public void run() {
                    chatAdapter.notifyDataSetChanged();
                    mListView.smoothScrollToPosition(chatAdapter.getCount() - 1);
//                    mListView.setSelection(chatAdapter.getCount()-1);
                }
            });
        }
    };

    /**
     * 获取到的消息的回调
     * @param event
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(MessageEvent event) {
        messages=event.messages;
        parseMessage(messages);

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EventBus.getDefault().register(this);  //注册
        setContentView(R.layout.activity_group_chat);
        Intent intent = getIntent();
        imid=intent.getStringExtra("imid");
        otherAvatar=intent.getStringExtra("otherAvatar");
        otherNickName=intent.getStringExtra("otherNickName");
        groupId=intent.getStringExtra("groupId");
        init();
        setAdapter();
        getAllMessage();
    }

    private void setAdapter() {
        chatAdapter=new ChatAdapter(getApplicationContext(),contentInfos);
        mListView.setAdapter(chatAdapter);

    }

    /**
     * 获取到消息的方法
     */
    private void getAllMessage() {

        Map<String, EMConversation> allConversations = EMClient.getInstance().chatManager().getAllConversations();
        Set<Map.Entry<String, EMConversation>> entries = allConversations.entrySet();
        Iterator<Map.Entry<String, EMConversation>> iterator = entries.iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, EMConversation> next = iterator.next();
            EMConversation value = next.getValue();
            if (value!=null){
                EMMessage lastMessage = value.getLastMessage();
                List<EMMessage> allMessages = value.getAllMessages();
                parseMessage(allMessages);
            }
        }
    }

    private void init() {
        mListView= (ListView) findViewById(R.id.group_chat_listview);
        mEditText= (EditText) findViewById(R.id.group_edit_contant);
        mTextViewTitle= (TextView) findViewById(R.id.group_text_title);
        mTextViewTitle.setText(otherNickName);
    }

    /**
     * 适配获取到的数据
     * @param list
     */
    private void parseMessage(List<EMMessage> list) {
        for (EMMessage message : list) {
            from = message.getFrom();
            if (message.getChatType() == EMMessage.ChatType.GroupChat) {//群聊消息
                EMMessage.Type type = message.getType();

                if (imid.equals(message.getTo())) { //判断是不是同一个聊天室的消息
                    ContentInfo info = new ContentInfo();

                if (type == EMMessage.Type.TXT) {
                    EMMessageBody body = message.getBody();
                    if (body instanceof EMTextMessageBody) {
                        //body
                        EMTextMessageBody body1 = (EMTextMessageBody) body;
                        String message1 = body1.getMessage();
                        info.setBody(message1);
                    }
                }
                if (type == EMMessage.Type.IMAGE) {
                    EMMessageBody body = message.getBody();
                    if (body instanceof EMImageMessageBody) {
                        EMImageMessageBody body1 = (EMImageMessageBody) body;
                        String thumbnailUrl = body1.getThumbnailUrl();
                        if(!thumbnailUrl.isEmpty()|| !TextUtils.isEmpty(thumbnailUrl)){
                            info.setImageUri(thumbnailUrl);
                        }else{
                            String localUrl = body1.getLocalUrl();
                            info.setImageUri(localUrl);
                        }
                    }
                }
                String id = message.getStringAttribute("id", "");
                String otherAvatar = message.getStringAttribute("head", "");
                Log.i("------meass",message.toString());

                Log.i("------uid",GaiaApp.getAppInstance().getUserInfo().id+"");

                if(message.getFrom().equals(GaiaApp.getAppInstance().getUserInfo().id+"")){
                    Log.i("------zijide",GaiaApp.getAppInstance().getUserInfo().id+"");
                    info.setType(0);
                }else{
                    info.setType(1);
                    Log.i("------taren","taren");
                }
                info.setOtherId(message.getTo());
                info.setUid(imid);
                info.setChose(id);
                info.setAvatar(otherAvatar);
                contentInfos.add(info);
                handler.sendEmptyMessage(0);
                }
            }
        }
    }

    /**
     * 发送按钮放置到软件盘上
     * @param event
     * @return
     */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if(event.getKeyCode() == KeyEvent.KEYCODE_ENTER&&event.getAction()==KeyEvent.ACTION_DOWN){
            /*隐藏软键盘*/
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(mEditText.getWindowToken(), 0);
            GroupSend();
            return true;
        }
        return true;
    }

    /**
     * 发送消息的方法
     */

    public void GroupSend() {
        String content=mEditText.getText().toString();
        EMMessage message = EMMessage.createTxtSendMessage(content, imid);
        if(message!=null){
            message.setChatType(EMMessage.ChatType.GroupChat);//群聊的标志
        }
       if((mEditText.getText().toString().isEmpty())){
           GaiaApp.showToast(getString(R.string.cant_be_null));
           return;
       }
        // 增加自己特定的属性
        message.setAttribute("id", GaiaApp.getAppInstance().getUserInfo().id);
        message.setAttribute("head", GaiaApp.getAppInstance().getUserInfo().avatar);
        message.setAttribute("nickName",GaiaApp.getAppInstance().getUserInfo().nickName);
        message.setAttribute("otherNickName",otherNickName);
        message.setAttribute("otherAvatar", otherAvatar);
        message.setAttribute("imid", imid);
        message.setAttribute("groupId",groupId);
        EMClient.getInstance().chatManager().sendMessage(message);
        //设置值
        ContentInfo info=new ContentInfo();
        //if(message.getFrom().toString().equals(GaiaApp.getAppInstance().getUserInfo().id+"");
        info.setType(0);
        info.setBody(mEditText.getText().toString());
        info.setUid(GaiaApp.getAppInstance().getUserInfo().id+"");
        info.setChose(GaiaApp.getAppInstance().getUserInfo().id+"");
        info.setAvatar(GaiaApp.getAppInstance().getUserInfo().avatar);
        contentInfos.add(info);
        mEditText.setText("");

        handler.sendEmptyMessage(0);

        //存储数据到环信

        EventBus.getDefault().post(new OnEventNew(1));
        msgs.add(message);
        EMClient.getInstance().chatManager().importMessages(msgs);
        message.setMessageStatusCallback(new EMCallBack(){
            @Override
            public void onSuccess() {

            }

            @Override
            public void onError(int i, String s) {
                GaiaApp.showToast(getString(R.string.please_wait_check));
            }

            @Override
            public void onProgress(int i, String s) {

            }
        });
        }

        public void GroupChatBack(View view) {
            finish();
        }

        @Override
        protected void onDestroy() {
            super.onDestroy();
            EMClient.getInstance().chatManager().removeMessageListener(msgListener);
            EventBus.getDefault().unregister(this);//取消注册
    }


    public void GroupOpenPhoto(View view) {
        pupuWindow();
        hintKey();
    }

    String imagePath=null;

    /**
     * 获取到图片的回传消息
     *
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null) {
            switch (requestCode) {
                case 0: //图库选择
                    if (data.getData() != null || data.getExtras() != null) { //防止没有返回结果
                        Uri uri = data.getData();
                        if (uri != null) {
                            //dismiss
                            if (popupWindow!=null&&popupWindow.isShowing()) {
                                popupWindow.dismiss();
                            }
                            imagePath = getAbsoluteImagePath(uri);
                            //设置值
                            ContentInfo info1=new ContentInfo();

                            info1.setUid(GaiaApp.getAppInstance().getUserInfo().id+"");
                            info1.setAvatar(GaiaApp.getAppInstance().getUserInfo().avatar);
                            info1.setImageUri(imagePath);
                            info1.setType(0);
                            info1.setChose(GaiaApp.getAppInstance().getUserInfo().id+"");
                            contentInfos.add(info1);
                            chatAdapter.notifyDataSetChanged();
                            sendImage(imagePath,imid);  //发送图片
                            mListView.smoothScrollToPosition(contentInfos.size()-1);
                        }
                    }else{
                        GaiaApp.showToast(getString(R.string.cant_find_img));
                    }
                    break;
                case 1:     //拍照的照片获取
                    if (data.getData() != null || data.getExtras() != null) { //防止没有返回结果
                        Uri uri = data.getData();
                        if(uri!=null){
                            String photoPath = getAbsoluteImagePath(uri);
                            ContentInfo info1=new ContentInfo();
                            info1.setUid(GaiaApp.getAppInstance().getUserInfo().id+"");
                            info1.setAvatar(GaiaApp.getAppInstance().getUserInfo().avatar);
                            info1.setImageUri(photoPath);
                            info1.setType(0);
                            info1.setChose(GaiaApp.getAppInstance().getUserInfo().id+"");
                            contentInfos.add(info1);
                            chatAdapter.notifyDataSetChanged();
                            sendImage(photoPath,imid);  //发送图片
                            mListView.smoothScrollToPosition(contentInfos.size()-1);

                        }
                    }else{
                        GaiaApp.showToast(getString(R.string.send_img_fail));
                    }
                    break;
            }
        }
    }

    /**
     * 发送图片的方法
     * @param imagePath
     * @param otherId
     */
    private void sendImage(String imagePath, String otherId) {

        EMMessage message = EMMessage.createImageSendMessage(imagePath, false, otherId);
        message.setChatType(EMMessage.ChatType.GroupChat);//群聊的表标志
        //如果是群聊，设置chattype，默认是单聊
        message.setAttribute("id", GaiaApp.getAppInstance().getUserInfo().id);
        message.setAttribute("head", GaiaApp.getAppInstance().getUserInfo().avatar);
        message.setAttribute("nickName",GaiaApp.getAppInstance().getUserInfo().nickName);
        message.setAttribute("otherNickName",otherNickName);
        message.setAttribute("otherAvatar", otherAvatar);
        message.setAttribute("imid", imid);
        message.setAttribute("groupId",groupId);
        EMClient.getInstance().chatManager().sendMessage(message);
        //存储消息数据
        msgs.add(message);
        EMClient.getInstance().chatManager().importMessages(msgs);
    }


    //弹窗
    private void pupuWindow() {
        View inflate = LayoutInflater.from(getApplicationContext()).inflate(R.layout.chat_popuwindow, null);
        popupWindow=new PopupWindow(inflate,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT);
        popupWindow.setFocusable(true);
        ColorDrawable dw = new ColorDrawable(0x00000000);
        popupWindow.setBackgroundDrawable(dw);
        popupWindow.setAnimationStyle(R.style.mypopwindow_anim_style);
        popupWindow.showAtLocation(this.findViewById(R.id.rea), Gravity.BOTTOM,0,0);

        photoFromMap= (TextView) inflate.findViewById(R.id.choose_from_photo);
        photoFromCarmer= (TextView) inflate.findViewById(R.id.choose_from_carmer);
        photoQuit= (TextView) inflate.findViewById(R.id.choose_quit);
        //选择照方式
        photoFromMap.setOnClickListener(new Listener());
        photoFromCarmer.setOnClickListener(new Listener());
        photoQuit.setOnClickListener(new Listener());
    }

    /**
     * 跳转到小组成员页面
     * @param view
     */
    public void GroupShow(View view) {
        if(groupId.isEmpty()){
            return;
        }
        ActivityUtil.startGroupActivity(GroupChatActivity.this,Long.valueOf(groupId));
    }

    /**
     * 弹窗的点击事件的监听
     */
    class Listener implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.choose_from_photo:
                    chooseFromPhotos();
                    break;
                case R.id.choose_from_carmer:
                    chooseFromPhoto();
                    break;
                case R.id.choose_quit:
                    popupWindow.dismiss();
            }
        }
    }

    /**
     * 从相册获取到图片
     */
    private void chooseFromPhoto() {
        Intent openCameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(openCameraIntent, TAKE_PICTURE);
    }

    /**
     * 从相机获取到图片
     */
    public void chooseFromPhotos() {
        // 激活系统图库，选择一张图片
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, PHOTO_FROM_MAP);
    }

    /**
     * 隐藏软件盘
     */
    public void hintKey(){
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(mEditText.getWindowToken(), 0);
    }
    //将Uri转化成为path路径
    protected String getAbsoluteImagePath(Uri uri) {
        // can post image
        String [] proj={MediaStore.Images.Media.DATA};
        Cursor cursor = managedQuery( uri,
                proj,       // Which columns to return
                null,       // WHERE clause; which rows to return (all rows)
                null,       // WHERE clause selection arguments (none)
                null);      // Order-by clause (ascending by name)

        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();

        return cursor.getString(column_index);
    }
}
