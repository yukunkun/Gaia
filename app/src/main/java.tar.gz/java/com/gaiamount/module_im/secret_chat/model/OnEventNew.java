package com.gaiamount.module_im.secret_chat.model;

/**
 * Created by yukun on 16-8-1.
 */
public class OnEventNew {
    public int num;
    public OnEventNew(int num){
            this.num=num;
    }
}
