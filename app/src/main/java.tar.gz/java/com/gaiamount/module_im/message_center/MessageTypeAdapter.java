package com.gaiamount.module_im.message_center;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.gaiamount.R;

/**
 * Created by haiyang-lu on 16-5-13.
 */
public class MessageTypeAdapter extends BaseAdapter {
    private static final int TYPE_EMPTY = 0;
    private static final int TYPE_NORMAL = 1;
    String[] typeListStr;
    int[] typeListIcon;
    private final LayoutInflater mInflater;
    private int[] messageCountList;

    public MessageTypeAdapter(Context context, int[] messageCountList) {
        this.messageCountList = messageCountList;
        typeListStr = context.getResources().getStringArray(R.array.message_type_list);
        typeListIcon = new int[]{R.mipmap.ic_message_official, R.mipmap.ic_messages};
        mInflater = LayoutInflater.from(context);
    }

    public void setOfficialMessageLocList(int[] messageCountList) {
        this.messageCountList = messageCountList;
    }

    @Override
    public int getCount() {
        return typeListStr.length;
    }

//    @Override
//    public int getViewTypeCount() {
//        return 2;
//    }
//
//    @Override
//    public int getItemViewType(int position) {
//        if (position == 2 || position == 6) {
//            return TYPE_EMPTY;
//        } else {
//            return TYPE_NORMAL;
//        }
//    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
//        if (getItemViewType(position) == TYPE_EMPTY) {
//            return mInflater.inflate(R.layout.item_list_divider_8dp, parent, false);
//        } else
//        {
        View view = mInflater.inflate(R.layout.item_messge_type, parent, false);
        ImageView icon = (ImageView) view.findViewById(R.id.message_type_icon);
        TextView title = (TextView) view.findViewById(R.id.message_type_title);
        TextView count = (TextView) view.findViewById(R.id.message_type_count);
        //icon
//            if (position == 0 || position == 1) {
//                icon.setBackgroundResource(typeListIcon[position]);
//            }
        if (position == 0) {
            icon.setBackgroundResource(typeListIcon[position]);
        }

        if (position==1) {
            icon.setBackgroundResource(typeListIcon[position]);
        }

        //标题
        title.setText(typeListStr[position]);

        //官方通知消息数量
        int num = messageCountList[position];

        if (num != 0) {
            count.setText(String.valueOf(num));
            count.setVisibility(View.VISIBLE);
        } else {
            count.setText("");
            count.setVisibility(View.GONE);
        }
        return view;
//        }
    }


}
