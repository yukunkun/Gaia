package com.gaiamount.module_im.message_center;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.gaiamount.R;
import com.gaiamount.gaia_main.BaseActionBarActivity;
import com.gaiamount.module_im.official.ChatActivity;
import com.gaiamount.module_im.official.ChatConstant;
import com.gaiamount.module_im.secret_chat.MySecretActivity;
import com.gaiamount.util.ImUtil;
import com.hyphenate.chat.EMClient;
import com.hyphenate.chat.EMConversation;


public class MessageActivity extends BaseActionBarActivity {

    public static final String MESSAGE_TYPE = "message_type";
    /**
     * 各类消息的未读数量
     */
    private int[] mCountList = new int[8];
    private MessageTypeAdapter mAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        ListView typeList = (ListView) findViewById(R.id.message_type_list);

        //获取各类消息的数量
        mCountList = ImUtil.computeMessageCount();

        mAdapter = new MessageTypeAdapter(this, mCountList);
        typeList.setAdapter(mAdapter);

        typeList.setOnItemClickListener(onItemClickListener);

    }


    @Override
    protected void onResume() {
        super.onResume();
        mCountList = ImUtil.computeMessageCount();
        mAdapter.notifyDataSetChanged();
    }

    public void markRead(EMConversation conversation) {
        if (conversation != null) {
            conversation.markAllMessagesAsRead();
        }
    }

    private AdapterView.OnItemClickListener onItemClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            //点击进入官方通知
            if (position == 0) {
                Intent intent = new Intent(MessageActivity.this, ChatActivity.class);
                intent.putExtra(MESSAGE_TYPE, ChatConstant.EXT_SYSTEM);
                EMConversation conversation = EMClient.getInstance().chatManager().getConversation(ChatConstant.USER_NAME_OFFICIAL);
                markRead(conversation);
                startActivity(intent);
            }

            //进入私信
            if (position == 1) {
                Intent intent = new Intent(MessageActivity.this, MySecretActivity.class);
                startActivity(intent);
            }

            mAdapter.setOfficialMessageLocList(mCountList);
            mAdapter.notifyDataSetChanged();

        }
    };


}
