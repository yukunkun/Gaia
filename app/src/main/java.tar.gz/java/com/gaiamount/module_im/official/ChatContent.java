package com.gaiamount.module_im.official;

/**
 * Created by haiyang-lu on 16-5-12.
 */
public class ChatContent {
    public String textContent;
    public String chatSender;
    public String avatar;
}
