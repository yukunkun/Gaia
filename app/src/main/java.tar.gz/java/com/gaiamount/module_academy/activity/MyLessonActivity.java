package com.gaiamount.module_academy.activity;

import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.gaiamount.R;
import com.gaiamount.apis.api_academy.AcademyApiHelper;
import com.gaiamount.module_academy.adapter.MyLessonAdapter;
import com.gaiamount.module_academy.bean.LessonInfo;
import com.gaiamount.util.ActivityUtil;
import com.gaiamount.util.network.MJsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * kun 我的课表
 */
public class MyLessonActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private LinearLayoutManager linearLayoutManager;
    private int t=0;
    private int pi=1;
    private ArrayList<LessonInfo> lessonInfos=new ArrayList<>();
    private MyLessonAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_lesson);
        init();
        getInfo();
        setAdapter();
        setListener();
    }

    private void init() {
        linearLayoutManager = new LinearLayoutManager(this);
        mRecyclerView= (RecyclerView) findViewById(R.id.my_lesson);
        mRecyclerView.setLayoutManager(linearLayoutManager);

        swipeRefreshLayout= (SwipeRefreshLayout) findViewById(R.id.swipe_refersh);
    }

    private void getInfo() {
        MJsonHttpResponseHandler handler=new MJsonHttpResponseHandler(MyLessonActivity.class){
            @Override
            public void onGoodResponse(JSONObject response) {
                super.onGoodResponse(response);
                paraJson(response);
            }
        };
        AcademyApiHelper.getLesson(t,pi,getApplicationContext(),handler);
    }

    private void paraJson(JSONObject response) {
        JSONArray a = response.optJSONArray("a");
        for (int i = 0; i < a.length(); i++) {
            LessonInfo lessonInfo=new LessonInfo();
            JSONObject object = a.optJSONObject(i);
            lessonInfo.setCover(object.optString("cover"));
            lessonInfo.setName(object.optString("name"));
            lessonInfo.setCid(object.optLong("cid"));
            lessonInfo.setId(object.optInt("id"));
            lessonInfo.setLen(object.optInt("len"));
            lessonInfo.setProgress(object.optInt("progress"));
            lessonInfo.setIsLearning(object.optInt("isLearning"));
            lessonInfo.setType(object.optInt("type"));
            JSONObject createTime = object.optJSONObject("createTime");
            long time = createTime.optLong("time");
            lessonInfo.setTime(time);
            lessonInfos.add(lessonInfo);
        }
        adapter.notifyDataSetChanged();
        swipeRefreshLayout.setRefreshing(false);
    }

    private void setAdapter() {
        adapter = new MyLessonAdapter(getApplicationContext(),lessonInfos);
        mRecyclerView.setAdapter(adapter);
    }

    private void setListener() {
        mRecyclerView.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                int lastVisibleItemPosition = linearLayoutManager.findLastCompletelyVisibleItemPosition();
                if (lastVisibleItemPosition == linearLayoutManager.getItemCount()-1) {
                    //加载更多
                    pi++;
                    getInfo();
                    adapter.notifyDataSetChanged();
                }
            }
        });
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                pi=1;
                getInfo();
            }
        });
    }

    public void MyLessonBack(View view) {
        finish();
    }

}
