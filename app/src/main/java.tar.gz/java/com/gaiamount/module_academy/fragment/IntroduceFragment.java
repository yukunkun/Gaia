package com.gaiamount.module_academy.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.gaiamount.R;
import com.gaiamount.module_academy.adapter.IntroduceAdapter;
import com.gaiamount.module_academy.bean.EventDetailInfo;
import com.gaiamount.module_academy.bean.OnEventId;
import com.gaiamount.widgets.CollapsibleTextView;
import com.gaiamount.widgets.ReadMoreTextView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

/**
 * Created by yukun on 16-8-3.
 */
public class IntroduceFragment extends Fragment {

    private ListView mListView;
    private TextView textViewIntro;
    private CollapsibleTextView collapsibleTextView;
    private IntroduceAdapter adapter;
    private String intr;
    private String sofeware;
    private ReadMoreTextView textView;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EventBus.getDefault().register(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(EventDetailInfo event) {
        intr = event.intr;
        sofeware = event.sofeware;
        if(sofeware.equals("null")){
            textViewIntro.setText("");
        }else {
            textViewIntro.setText(sofeware);
        }if(intr.equals("null")){
//            collapsibleTextView.setDesc("",collapsibleTextView, TextView.BufferType.NORMAL);
            textView.setText("");
        }else {
//            collapsibleTextView.setDesc(intr+""+intr+intr,collapsibleTextView, TextView.BufferType.NORMAL);
                textView.setText(intr);
        }
    }
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View inflate =inflater.inflate(R.layout.academy_introduce_head,null);
        init(inflate);
        getInfo();
        setAdapter();
        return inflate;
    }

    private void init(View inflate) {
//        mListView = (ListView) inflate.findViewById(R.id.academy_introduce_listview);
//        View inflate1 = LayoutInflater.from(getContext()).inflate(R.layout.academy_introduce_head,null);
//        mListView.addHeaderView(inflate1);
        textViewIntro= (TextView) inflate.findViewById(R.id.textview_software_use);
//        collapsibleTextView= (CollapsibleTextView) inflate.findViewById(R.id.resdmore_textview);
//        collapsibleTextView.setDesc("",collapsibleTextView, TextView.BufferType.NORMAL);
        textView= (ReadMoreTextView) inflate.findViewById(R.id.staff);
    }

    private void getInfo() {

    }

    private void setAdapter() {
//        adapter = new IntroduceAdapter(getContext());
//        mListView.setAdapter(adapter);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(getContext());
    }
}
