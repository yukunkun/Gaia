package com.gaiamount.module_academy.bean;

/**
 * Created by yukun on 16-8-5.
 */
public class Contents {
    private int ind;
    private String name;
    private long chapterId;

    public long getChapterId() {
        return chapterId;
    }

    public void setChapterId(long chapterId) {
        this.chapterId = chapterId;
    }

    public int getInd() {
        return ind;
    }

    public void setInd(int ind) {
        this.ind = ind;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
