package com.gaiamount.module_academy.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.gaiamount.R;
import com.gaiamount.apis.Configs;
import com.gaiamount.module_academy.bean.LessonInfo;
import com.gaiamount.module_academy.bean.MixInfo;
import com.gaiamount.util.ActivityUtil;
import com.gaiamount.util.StringUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by yukun on 16-8-2.
 */
public class MyLessonAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private ArrayList<LessonInfo> lessonInfos;
    Context context;
    public MyLessonAdapter(Context context, ArrayList<LessonInfo> lessonInfos){
        this.context=context;
        this.lessonInfos=lessonInfos;
    }
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(context).inflate(R.layout.academy_loadmore, null);
        LessonViewHolder holder=new LessonViewHolder(inflate);
        return holder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        final LessonInfo mixInfo = lessonInfos.get(position);
        ((LessonViewHolder)holder).textViewIntroduce.setText(mixInfo.getName());

        Glide.with(context).load(Configs.COVER_PREFIX +mixInfo.getCover()).into(((LessonViewHolder)holder).imageViewImg);

        ((LessonViewHolder)holder).textViewTime.setText(getTime(mixInfo.getTime()));

        int type = mixInfo.getType();
        //判断视频类型
        if(type==0){
            ((LessonViewHolder)holder).imageViewDevide.setImageResource(R.mipmap.ic_tw);
        }else if(type==1){
            ((LessonViewHolder)holder).imageViewDevide.setImageResource(R.mipmap.ic_video);
        }else if(type==2){
            ((LessonViewHolder)holder).imageViewDevide.setImageResource(R.mipmap.ic_live);
        }

        int progress = mixInfo.getProgress();
        int len = mixInfo.getLen();
        int percent=(int)progress*100/len;
        if(percent==100){
            ((LessonViewHolder) holder).textViewPrice.setText("已学完");
        }else if(percent==0){
            ((LessonViewHolder) holder).textViewPrice.setText("还未学");
        }else {
            ((LessonViewHolder) holder).textViewPrice.setText(percent+"%");
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityUtil.startAcademyDetailActivity(Long.valueOf(mixInfo.getCid()),context);
            }
        });
    }

    @Override
    public int getItemCount() {
        return lessonInfos.size();
    }

    class LessonViewHolder extends RecyclerView.ViewHolder{

        public TextView textViewIntroduce,textViewPrice,textViewTime,textViewLearn;
        public ImageView imageViewImg, imageViewDevide;
        public LessonViewHolder(View itemView) {
            super(itemView);
            textViewIntroduce= (TextView) itemView.findViewById(R.id.academy_introduce);
            textViewPrice= (TextView) itemView.findViewById(R.id.academy_price);
            textViewTime= (TextView) itemView.findViewById(R.id.academy_time);
            textViewLearn= (TextView) itemView.findViewById(R.id.academy_textview_learn);
            imageViewImg= (ImageView) itemView.findViewById(R.id.academy_img_map);
            imageViewDevide= (ImageView) itemView.findViewById(R.id.academy_devide);
        }
    }

    private String getTime(long msgTime) {
        long l = System.currentTimeMillis();
        if(l-msgTime<3600000){
            SimpleDateFormat formatter = new SimpleDateFormat    ("mm");
            Date curDate = new Date(msgTime);//获取时间
            String str1 = formatter.format(curDate);
            Date curDate2 = new Date(System.currentTimeMillis());//获取当前时间
            String str = formatter.format(curDate2);
            int i = Integer.valueOf(str) - Integer.valueOf(str1);
            if(i>=0){
                return i+context.getString(R.string.time_minute_ago);
            }else {
                return 60+i+context.getString(R.string.time_minute_ago);
            }
        }
        if(3600000<l-msgTime&l-msgTime<86400000){
            SimpleDateFormat formatter = new SimpleDateFormat    ("hh");
            Date curDate = new Date(msgTime);//获取时间
            String str1 = formatter.format(curDate);
            Date curDate2 = new Date(l);//获取当前时间
            String str = formatter.format(curDate2);
            int i = Integer.valueOf(str) - Integer.valueOf(str1);
            if(i>=0){
                return i+context.getString(R.string.time_hours_ago);
            }else {
                return 24+i+context.getString(R.string.time_hours_ago);
            }
        }else if(l-msgTime>86400000 & l-msgTime<=86400000*2){
            return context.getString(R.string.one_day_ago);
        }else if(l-msgTime>86400000*2 & l-msgTime<=86400000*3){
            return context.getString(R.string.two_day_ago);
        }else if(l-msgTime>86400000*3 & l-msgTime<=86400000*4) {
            return context.getString(R.string.three_day_ago);
        }else {
            SimpleDateFormat formatter = new SimpleDateFormat    ("yyyy/MM/dd");
            Date curDate = new Date(msgTime);//获取时间
            return formatter.format(curDate);
        }
    }

}
