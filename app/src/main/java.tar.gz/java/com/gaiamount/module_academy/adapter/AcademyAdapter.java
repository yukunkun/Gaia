package com.gaiamount.module_academy.adapter;

import android.content.Context;
import android.os.Handler;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import com.gaiamount.R;
import com.gaiamount.module_academy.bean.OnEventId;
import com.gaiamount.module_academy.viewholder.ViewHolderMore;
import com.gaiamount.module_academy.viewholder.ViewHolderText;
import com.gaiamount.module_academy.viewholder.ViewPager2Holder;
import com.gaiamount.module_academy.viewholder.ViewPagerHolder;
import com.gaiamount.module_im.secret_chat.model.MessageEvent;
import com.gaiamount.util.ScreenUtils;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;

/**
 * Created by yukun on 16-8-2.
 */
public class AcademyAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private int BANNER_TYPE=0;
    private int DEVIDE_TYPE=1;
    private int TEXT_MORE=2;
    private int collegeId;
    private ArrayList<String> covers;
    private boolean temp;
    private Context context;
    private BannerAdapter bannerAdapter;
    private int i=0;
    int id;
    private Handler handler=new Handler();
    public AcademyAdapter(Context context, int collegeId, ArrayList<String> covers){
        this.context=context;
        this.covers=covers;
        this.collegeId=collegeId;
        EventBus.getDefault().register(this);

    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(OnEventId event) {
        id = event.id;
        EventBus.getDefault().unregister(this);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view=null;
        if(viewType==BANNER_TYPE){
            view= LayoutInflater.from(context).inflate(R.layout.academy_viewpager,null);
            ViewPagerHolder holder=new ViewPagerHolder(view);
            return holder;
        }else
        if(viewType==DEVIDE_TYPE){
            view= LayoutInflater.from(context).inflate(R.layout.academy_viewpager,null);
            ViewPager2Holder holder=new ViewPager2Holder(view);
            return holder;
        }else
        if(viewType==TEXT_MORE){
            view= LayoutInflater.from(context).inflate(R.layout.academy_text_viewholder,null);
            ViewHolderText holder=new ViewHolderText(view);
            return holder;
        }else {
            view= LayoutInflater.from(context).inflate(R.layout.academy_loadmore,null);
            ViewHolderMore holder=new ViewHolderMore(view);
            return holder;
        }

    }


    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if(holder instanceof ViewPagerHolder){

            bannerAdapter = new BannerAdapter(context,covers);

            ViewGroup.LayoutParams layoutParams = ((ViewPagerHolder)holder).viewPager.getLayoutParams();
            layoutParams.height = getHeight();
            ((ViewPagerHolder)holder).viewPager.setLayoutParams(layoutParams);

            ((ViewPagerHolder)holder).viewPager.setAdapter(bannerAdapter);
            SlideBanner(((ViewPagerHolder)holder).viewPager);

        }else if(holder instanceof ViewPager2Holder){

            DevideViewPagerAdapter pagerAdapter=new DevideViewPagerAdapter(context,id);

            ViewGroup.LayoutParams layoutParams = ((ViewPager2Holder)holder).viewPager.getLayoutParams();
            layoutParams.height = getHeight2();
            ((ViewPager2Holder)holder).viewPager.setLayoutParams(layoutParams);

            ((ViewPager2Holder)holder).viewPager.setAdapter(pagerAdapter);
            pagerAdapter.notifyDataSetChanged();

        }else if(holder instanceof ViewHolderText){

        }else if(holder instanceof ViewHolderMore){

        }
    }
    //自动滑动
    private void SlideBanner(final ViewPager viewPager) {
        if(covers.size()!=0){
            temp=true;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(temp){
                    try {
                        Thread.sleep(4000);
                        i++;
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                viewPager.setCurrentItem(i);
                            }
                        });
                        if(i==covers.size()){
                            i=0;
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();

    }

    @Override
    public int getItemCount() {
        return 3;
    }

    @Override
    public int getItemViewType(int position) {
       if(position==0){
           return BANNER_TYPE;
       }else if(position==1){
           return DEVIDE_TYPE;
       }else if(position==2){
           return TEXT_MORE;
       }else {
           return position;
       }
    }

    public int getHeight(){//设置宽高比例
        int itemHeight;
        int width = ScreenUtils.instance().getWidth();
        itemHeight = (int) ((width)*0.3);
        return itemHeight;
    }
    public int getHeight2(){//设置宽高比例
        int itemHeight;
        int width = ScreenUtils.instance().getWidth();
        itemHeight = (int) ((width)*0.2);
        return itemHeight;
    }
}
