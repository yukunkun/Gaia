package com.gaiamount.module_academy.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.SeekBar;
import android.widget.TextView;

import com.gaiamount.R;
import com.gaiamount.apis.api_academy.AcademyApiHelper;
import com.gaiamount.apis.api_creator.GroupApi;
import com.gaiamount.gaia_main.GaiaApp;
import com.gaiamount.module_player.bean.VideoDetailInfo;
import com.gaiamount.util.LogUtil;
import com.gaiamount.util.ScreenUtils;
import com.gaiamount.util.StringUtil;
import com.gaiamount.util.network.MJsonHttpResponseHandler;
import com.gaiamount.widgets.media.GMediaController;
import com.gaiamount.widgets.media.GVideoView;
import com.gaiamount.widgets.media.IGMediaController;

import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.IOException;
import java.util.ArrayList;

import cn.sharesdk.framework.ShareSDK;
import cn.sharesdk.onekeyshare.OnekeyShare;
import fr.castorflex.android.circularprogressbar.CircularProgressBar;
import tv.danmaku.ijk.media.player.IMediaPlayer;
import tv.danmaku.ijk.media.player.IjkMediaPlayer;
import tv.danmaku.ijk.media.player.MediaPlayerProxy;

//kun  academy播放页
public class AcademyPlayActivity extends AppCompatActivity implements View.OnClickListener {
    private int HINT_CONTROL=1;
    private int UPDATE_SEEKBAR=0;
    private int SHOW_CONTROLL=0;
    private SurfaceView mSurfaceView;
    private IjkMediaPlayer mIjkMediaPlayer;
    private MediaPlayerProxy mPlayerProxy;
    private Toolbar toolbar;
    private LinearLayout linShareNext,mLinHeadToobar;
    private ImageView mPause,mVoice;
    private SeekBar mSeekBar;
    private LinearLayout mLinDowmContril;
    private TextView mCurrentTime,mAllTime,mStudyOver,mRatioText,mShare,mNext;
    private StringUtil mStringUtil=StringUtil.getInstance();
    private CircularProgressBar progressBar;
    private int videoDuration;
    private AudioManager am;
    private GVideoView controller;

    private long cid;
    private long chapterId;
    private ArrayList<Integer> hidList;
    private int childPosition;
    String url="http://qv.gaiamount.com/playlist/u110/v109_mp4.m3u8?e=1468844302&token=_6yhTpZI-AHtfULMSiW7eOCvrNEnOS_YcLV9GNfH:_3oVS32zk5XO8Z8GTBrxz3GUTyo=";
    String URI2="http://qv.gaiamount.com/playlist/u3320/v3310_mp4.m3u8?e=1470708869&token=_6yhTpZI-AHtfULMSiW7eOCvrNEnOS_YcLV9GNfH:aCqTqhZoFBa6OuWJDXEFjaH9Zig=";
    private Handler handler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what==UPDATE_SEEKBAR){

                long videoCachedDuration = mIjkMediaPlayer.getVideoCachedDuration();
                int currentPosition = (int) mIjkMediaPlayer.getCurrentPosition();
                String currenPos = mStringUtil.stringForTime(currentPosition);
                mSeekBar.setProgress(currentPosition);
                mSeekBar.setSecondaryProgress(currentPosition+(int) videoCachedDuration);
                mCurrentTime.setText(currenPos);

            }
            if(msg.what==HINT_CONTROL){
                hint();
                showOrHint=true;
            }
            handler.sendEmptyMessageDelayed(UPDATE_SEEKBAR,1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //设置无标题
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        //设置全屏
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_academy_play);

        //初始化IJKPlayer
        IjkMediaPlayer.loadLibrariesOnce(null);
        IjkMediaPlayer.native_profileBegin("libijkplayer.so");
        mIjkMediaPlayer = new IjkMediaPlayer();
        mPlayerProxy = new MediaPlayerProxy(mIjkMediaPlayer);
        mPlayerProxy.setLooping(true);
        Intent intent = getIntent();
        cid = intent.getLongExtra("cid", -1);
        chapterId=intent.getLongExtra("chapterId",-1);
        hidList=intent.getIntegerArrayListExtra("hidList");
        childPosition=intent.getIntExtra("childPosition",-1);
        init();
        initToobar();
        getInfo();


        setListener();


    }
    //初始化toobar
    private void initToobar() {
        toolbar.setTitle("gaiament");
        toolbar.setNavigationIcon(R.mipmap.back_normal);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    //初始化控件
    private void init() {
        //初始化声音控制
        am = (AudioManager) getApplicationContext().getSystemService(Context.AUDIO_SERVICE);

        mSurfaceView= (SurfaceView) findViewById(R.id.surfview);
        toolbar= (Toolbar) findViewById(R.id.play_toobar);
        linShareNext= (LinearLayout) findViewById(R.id.line_share_next);
        mPause= (ImageView) findViewById(R.id.image_pause);
        mVoice= (ImageView) findViewById(R.id.image_voice);
        mRatioText= (TextView) findViewById(R.id.textview_ratio);
        mSeekBar= (SeekBar) findViewById(R.id.seekbar);
        mCurrentTime= (TextView) findViewById(R.id.textview_current_time);
        mAllTime= (TextView) findViewById(R.id.textview_all_time);
        mShare= (TextView) findViewById(R.id.textview_share);
        mNext= (TextView) findViewById(R.id.textview_next);
        mStudyOver= (TextView) findViewById(R.id.textview_study_over);
        mLinDowmContril= (LinearLayout) findViewById(R.id.lin_down_control);
        mLinHeadToobar= (LinearLayout) findViewById(R.id.lin_head_toobar);
        progressBar= (CircularProgressBar) findViewById(R.id.academy_progressBar);
        mSoundView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.acadecy_voice_seekbar, null);
        mRatioLayout= LayoutInflater.from(getApplicationContext()).inflate(R.layout.item_player_ration, null);
        //初始化Voice的seekbar和分辨率的popu
        initRation(mRatioLayout);
        initSeekbar();
    }

    private void initRation(View mRatioLayout) {
        mFraOrigin= (FrameLayout) mRatioLayout.findViewById(R.id.definitionOrigin);
        mFraHD=(FrameLayout) mRatioLayout.findViewById(R.id.definitionHD);
        mFra720P=(FrameLayout) mRatioLayout.findViewById(R.id.definition720P);
        mFra2K=(FrameLayout) mRatioLayout.findViewById(R.id.definition2K);
        mFraOrigin.setOnClickListener(new RationListener());
        mFraHD.setOnClickListener(new RationListener());
        mFra720P.setOnClickListener(new RationListener());
        mFra2K.setOnClickListener(new RationListener());
    }

    //分辨率的切换点击
    private class RationListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.definitionOrigin:

                    controller=new GVideoView(getApplicationContext());
                    controller.setVideoURI(Uri.parse(url));

                    mRatioText.setText(getResources().getString(R.string.origin_definition));
                    popupWindow.dismiss();
                break;
                case R.id.definition720P:

                    mRatioText.setText("720P");
                    popupWindow.dismiss();
                break;
                case R.id.definitionHD:

                    mRatioText.setText("HD");
                    popupWindow.dismiss();
                    break;
                case R.id.definition2K:

                    mRatioText.setText("2K");
                    popupWindow.dismiss();
                    break;

            }
        }
    }
    private void getInfo() {
        MJsonHttpResponseHandler handler=new MJsonHttpResponseHandler(AcademyPlayActivity.class){
            @Override
            public void onGoodResponse(JSONObject response) {
                super.onGoodResponse(response);
                parasJson(response);

            }
        };

        AcademyApiHelper.getVideo(cid,chapterId,hidList.get(childPosition),getApplicationContext(),handler);

    }
    private String defaultUri="";
    private void parasJson(JSONObject response) {

        if(response.length()==0||response.equals("null")||response.toString().isEmpty()){
            GaiaApp.showToast(getString(R.string.academy_play));
            popupHandler.sendEmptyMessageDelayed(1,3000);
            return;
        }

        Log.i("-----res",response+"+");
        JSONObject o = response.optJSONObject("o");
        defaultUri = selectDefaultUri(o);
        setVideoListener(defaultUri);
    }

    public void setVideoListener(String uri) {
        try {

//            mPlayerProxy.setDataSource(uri);
            mPlayerProxy.setDataSource(URI2);
            mPlayerProxy.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mPlayerProxy.setOnPreparedListener(new IMediaPlayer.OnPreparedListener() {


                @Override
                public void onPrepared(IMediaPlayer mp) {
                    mp.setDisplay(mSurfaceView.getHolder());
                    mp.start();
                    //加载的progressbar
                    progressBar.setVisibility(View.GONE);
                    //获取到视频的最大时间
                    videoDuration = (int) mp.getDuration();
                    String duration = mStringUtil.stringForTime(videoDuration);
                    mAllTime.setText(duration);//时间
                    //进度最大
                    mSeekBar.setMax(videoDuration);
                    //获取当前的进度
                    int currentPosition = (int)mp.getCurrentPosition();
                    String currentTime = mStringUtil.stringForTime(currentPosition);
                    mCurrentTime.setText(currentTime);
                    //发送消息，实时更新进度条
                    handler.sendEmptyMessage(UPDATE_SEEKBAR);
                    handler.sendEmptyMessageDelayed(HINT_CONTROL,3000);
                    mSeekBar.setOnSeekBarChangeListener(new onSeekBarChangeListener());
                }
            });
        } catch (Exception e) {
            GaiaApp.showToast(getString(R.string.play_error));
            e.printStackTrace();
        }

        mPlayerProxy.setOnErrorListener(new IMediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(IMediaPlayer mp, int what, int extra) {
                return false;
            }
        });
        //开始播放
        startPlay();
    }

    //进度条的监听
    private class onSeekBarChangeListener implements SeekBar.OnSeekBarChangeListener {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            if (fromUser){
                seekBar.setProgress(progress);
                mPlayerProxy.seekTo(progress);
                String current = mStringUtil.stringForTime(progress);
                mCurrentTime.setText(current);
            }
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }
    }

    private void setListener() {
        mPause.setOnClickListener(this);
        mVoice.setOnClickListener(this);
        mRatioText.setOnClickListener(this);
        mShare.setOnClickListener(this);
        mNext.setOnClickListener(this);
        mStudyOver.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.image_pause:
                startPlay();
                break;
            case R.id.image_voice:
                showPopVoice();
                break;
            case R.id.textview_ratio:
                showPopUp();
                break;
            case R.id.textview_share:
                share();
                break;
            case R.id.textview_next:
                nextPlay();
                break;
            case R.id.textview_study_over:
                studyOver();
                break;
        }
    }
    // 播放下一节
    private void nextPlay() {
        if(childPosition+1<hidList.size()){
            hidList.get(childPosition+1);
//            getInfo();
            try {

                controller=new GVideoView(getApplicationContext());
                controller.setVideoURI(Uri.parse(url));
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            linShareNext.setVisibility(View.GONE);
            mStudyOver.setBackgroundResource(R.drawable.shape_play_unpressed);
            mStudyOver.setTextColor(getResources().getColor(R.color.color_ff5773));
        }else{
            GaiaApp.showToast("播放完毕,没有下一节的");
        }
    }

    //
    private void share() {


    }

    //播放下一节课程
    public void studyOver(){
        //移除3s隐藏控制栏
        handler.removeMessages(HINT_CONTROL);
        linShareNext.setVisibility(View.VISIBLE);
        mStudyOver.setBackgroundResource(R.drawable.shape_play_pressed);
        mStudyOver.setTextColor(getResources().getColor(R.color.white));
        progressBar.setVisibility(View.GONE);
//        mSeekBar.setProgress(videoDuration);
        pauseVideo();

    }
    //判断是否是第一次播放
    private boolean isFirstPlay=false;
    //开始播放
    public void startPlay(){
        if (mPlayerProxy.isPlaying()) {
            pauseVideo();
        }else if (mIjkMediaPlayer.isPlayable()) {
            if (!isFirstPlay) {
                mPlayerProxy.prepareAsync();
                isFirstPlay = true;
                mPause.setImageResource(R.mipmap.pause);
            }else {
                startVideo();
            }
        }
    }


    private PopupWindow popupWindow;
    private FrameLayout  mFraOrigin, mFra720P,mFraHD,mFra2K;
    private View mRatioLayout;
    //show 分辨率的 popu
    private void showPopUp() {

        popupWindow = new PopupWindow(mRatioLayout,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());

        mRatioLayout.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        int height = mRatioLayout.getMeasuredHeight();
        setPopupWindow(popupWindow, mRatioText, -ScreenUtils.dp2Px(getApplicationContext(), 50), -height - ScreenUtils.dp2Px(getApplicationContext(), 40));
    }
    //声音的pop
    private PopupWindow mPopupSound;

    private void showPopVoice() {
        if (mPopupSound == null) {
            mPopupSound = new PopupWindow(mSoundView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            mPopupSound.setBackgroundDrawable(getResources().getDrawable(R.color.black60));
        }
        mSoundView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        int height = mSoundView.getMeasuredHeight();
        LogUtil.w(GMediaController.GMediaPlayerControl.class, "measuredHeight:" + height);

        setPopupWindow(mPopupSound, mVoice, ScreenUtils.dp2Px(getApplicationContext(), 10), -height - ScreenUtils.dp2Px(getApplicationContext(), 40));

    }

    private SeekBar mSoundSeek;
    private View mSoundView;

    public void initSeekbar(){
            mSoundSeek = (SeekBar) mSoundView.findViewById(R.id.soundSeek);
            mSoundSeek.setMax(am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));//android音量级数
            //设置为系统当前音量
            mSoundSeek.setProgress(am.getStreamVolume(AudioManager.STREAM_MUSIC));

            mSoundSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    if (!fromUser) {
                        return;
                    }
                    //根据progress的改变而改变音量
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0);
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {

                }
            });
    }


    private Handler popupHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case 0:

                    break;
                case 1:
                    finish();
                    break;
            }
        }
    };

    private String k2="";
    private String p720="";
    private String hd="";
    private String mp4="";

    //默认的uri
    private String selectDefaultUri(JSONObject o) {
        String defaultPath = null;
        k2 = o.optString("k2");
        p720 = o.optString("p720");
        hd = o.optString("hd");
        mp4 = o.optString("mp4");
        //mp4
        if (!TextUtils.isEmpty(mp4)&&!mp4.equals("null")&&mp4.length()!=0) {
            mRatioText.setText("原画");
            defaultPath = mp4;
        }
        //HD
        if (!TextUtils.isEmpty(hd)&&!hd.equals("null")&&hd.length()!=0) {

            if(mFraHD.getVisibility()==View.GONE){
                mFraHD.setVisibility(View.VISIBLE);
            }
            mRatioText.setText("HD");
            defaultPath = hd;

        } else {
            mFraHD.setVisibility(View.GONE);
        }
        //p720
        if (!TextUtils.isEmpty(p720)&&!p720.equals("null")&&p720.length()!=0) {
            if(mFra720P.getVisibility()==View.GONE){
                mFra720P.setVisibility(View.VISIBLE);
            }
            mRatioText.setText("720P");
            defaultPath = p720;
        } else {
            mFra720P.setVisibility(View.GONE);
        }

        //2K
        if (!TextUtils.isEmpty(k2)&&!k2.equals("null")&&k2.length()!=0) {
            if(mFra2K.getVisibility()==View.GONE){
                mFra2K.setVisibility(View.VISIBLE);
            }
            defaultPath = k2;
            mRatioText.setText("2K");
        } else {
            mFra2K.setVisibility(View.GONE);
        }

        return defaultPath;
    }

    /**
     * 开始
     */
    private void startVideo() {
        mPlayerProxy.start();
        linShareNext.setVisibility(View.GONE);
        mPause.setImageResource(R.mipmap.pause);
    }

    /**
     * 暂停
     */
    private void pauseVideo() {
        mPlayerProxy.pause();
        mLinHeadToobar.setVisibility(View.VISIBLE);
        mPause.setImageResource(R.mipmap.play);
    }

    //返回键
    public void AcademyPlayBack(View view) {
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mIjkMediaPlayer.stop();
        mIjkMediaPlayer.release();
    }

    public void setPopupWindow(PopupWindow popupWindow, View view, int offsetX, int offsetY) {
        //在其上方显示控件
        if (popupWindow != null && popupWindow.isShowing()) {
            popupWindow.dismiss();
        } else {
            LogUtil.d(GMediaController.GMediaPlayerControl.class, "offsetX:" + offsetX + ",offsetY:" + offsetY);
            popupWindow.showAsDropDown(view, offsetX, offsetY);
        }
    }

    boolean showOrHint=true;
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction()==MotionEvent.ACTION_DOWN){
            if(showOrHint){
                showCon();
                showOrHint=false;
                handler.sendEmptyMessageDelayed(HINT_CONTROL,4000);
            }else if(!showOrHint){
                hint();
                showOrHint=true;
                handler.removeMessages(HINT_CONTROL);
            }
        }

        return super.onTouchEvent(event);
    }


    private void showCon(){
        mLinDowmContril.setVisibility(View.VISIBLE);
        mLinHeadToobar.setVisibility(View.VISIBLE);
    }

    private void hint(){
        mLinDowmContril.setVisibility(View.GONE);
        mLinHeadToobar.setVisibility(View.GONE);
        if(popupWindow!=null&&popupWindow.isShowing()){
            popupWindow.dismiss();
        }
    }



}
