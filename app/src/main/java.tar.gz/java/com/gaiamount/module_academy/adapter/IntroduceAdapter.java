package com.gaiamount.module_academy.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.gaiamount.R;

/**
 * Created by yukun on 16-8-3.
 */
public class IntroduceAdapter extends BaseAdapter {
    Context context;
    public IntroduceAdapter (Context context){
        this.context=context;
    }
    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View inflate = LayoutInflater.from(context).inflate(R.layout.introduce_listview_item, null);
        return convertView;
    }

}
