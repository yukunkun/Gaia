package com.gaiamount.module_academy.activity;

import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.gaiamount.R;
import com.gaiamount.apis.Configs;
import com.gaiamount.apis.api_academy.AcademyApiHelper;
import com.gaiamount.gaia_main.GaiaApp;
import com.gaiamount.module_academy.bean.EventDetailInfo;
import com.gaiamount.module_academy.fragment.ContentFragment;
import com.gaiamount.module_academy.fragment.IntroduceFragment;
import com.gaiamount.module_im.secret_chat.adapter.SecViewPagerAdapter;
import com.gaiamount.util.ScreenUtils;
import com.gaiamount.util.image.ImageUtils;
import com.gaiamount.util.network.MJsonHttpResponseHandler;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONObject;

import java.util.ArrayList;

import cn.sharesdk.framework.ShareSDK;
import cn.sharesdk.onekeyshare.OnekeyShare;

/**
 * kun academy的详情页
 */
public class AcademyDetailActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageView imageViewCover;
    private TextView textViewIntro, textViewLearnNum,textViewPrice,textViewLearn;
    private TabLayout mTabLayout;
    private ViewPager mViewPager;
    private SecViewPagerAdapter adapter;
    private ArrayList<Fragment> fragments;
    private String[] strings;
    private Toolbar mToolbar;
    private long uid;
    private long cid;
    private int t=1; // 中文/英文教程 	0中文教程　１英文教程

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_academy_detail);
        Intent intent = getIntent();
        cid=intent.getLongExtra("id",-1);
        uid= GaiaApp.getAppInstance().uId;
        init();
        initToobar();
        getInfo();
        getFragment();
        setListener();
        setAdapter();
    }

    //获取到屏幕的宽度
    public int getWidght(){
        int width = ScreenUtils.instance().getWidth();
        return width;
    }

    private void init() {
        imageViewCover= (ImageView) findViewById(R.id.academy_cover);
        //动态设置imageview的宽度
        ViewGroup.LayoutParams linearParams =imageViewCover.getLayoutParams(); //取控件textView当前的布局参数
        linearParams.height = (int)(getWidght()/1.66);// 控件的高强制设成1.66:1
        imageViewCover.setLayoutParams(linearParams); //使设置好的布局参数应用到控件

        //动态设置textview的宽度
        textViewIntro= (TextView) findViewById(R.id.academy_detail_name);
        ViewGroup.LayoutParams linearParams1 = textViewIntro.getLayoutParams();
        linearParams1.width = (int)(getWidght()*0.8);
        textViewIntro.setLayoutParams(linearParams1);

        textViewLearnNum= (TextView) findViewById(R.id.learn_number);
        textViewPrice= (TextView) findViewById(R.id.learn_price);
        mTabLayout= (TabLayout) findViewById(R.id.academy_tablayout);
        mViewPager = (ViewPager) findViewById(R.id.academy_viewpager);
        mToolbar = (Toolbar) findViewById(R.id.academy_toobar);
        textViewLearn= (TextView) findViewById(R.id.start_learn);
    }

    //toobar
    private void initToobar() {
        mToolbar.setTitle("");
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        mToolbar.inflateMenu(R.menu.academy_mix_menu);

    }
    //toobar的点击事件

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        Toast.makeText(AcademyDetailActivity.this, "share", Toast.LENGTH_SHORT).show();
        if(itemId==R.id.action_share_academy){
            share();
        }

        return super.onOptionsItemSelected(item);
    }

    //分享功能
    private void share() {
        ShareSDK.initSDK(this);
        OnekeyShare oks = new OnekeyShare();
        oks.setTitle("盖亚");
        oks.setTitleUrl("http://www.gaiamount.com");
//        oks.setText(mDetailInfo.getWorks().getName());
//        oks.setImageUrl(ImageUtils.COVER_PREFIX+mDetailInfo.getVideoInfo().getScreenshot());
        oks.setUrl("http://www.gaiamount.com");
        oks.setSiteUrl("http://www.gaiamount.com");
        oks.setSilent(true);
        //打开界面
        oks.show(this);
    }

    //获取数据
    private void getInfo() {

        MJsonHttpResponseHandler handler=new MJsonHttpResponseHandler(AcademyDetailActivity.class){
            @Override
            public void onGoodResponse(JSONObject response) {
                super.onGoodResponse(response);
                parasJson(response);

            }
        };
        AcademyApiHelper.getDetail(uid,cid,t,getApplicationContext(),handler);
        //判断是否学习
        study1();
    }

    private void parasJson(JSONObject response) {
        JSONObject oo = response.optJSONObject("o");
        JSONObject o = oo.optJSONObject("course");

        int learningCount = o.optInt("learningCount");
        textViewLearnNum.setText(learningCount+"");
        String name = o.optString("name");
        textViewIntro.setText(name);
        int allowFree = o.optInt("allowFree");
        int price = o.optInt("price");
        if(allowFree==0){
            textViewPrice.setText(R.string.for_free);
        }else {
            textViewPrice.setText(price+"元");
        }
        String cover = o.optString("cover");
        Glide.with(getApplicationContext()).load(Configs.COVER_PREFIX+cover).into(imageViewCover);
        //传值到fragment
        long id = o.optLong("id");
        String description = o.optString("description");
        String equipment = o.optString("equipment");
        EventBus.getDefault().post(new EventDetailInfo(description,equipment,id,cid));


    }

    private void getFragment() {
        //设置viewpager的fragment
        fragments=new ArrayList<>();
        IntroduceFragment introduceFragment=new IntroduceFragment();
        fragments.add(introduceFragment);
        ContentFragment contentFragment=new ContentFragment();
        fragments.add(contentFragment);

        //设置tablayout的标签
        strings=getApplicationContext().getResources().getStringArray(R.array.academy_tablayout);
        for (int i = 0; i < strings.length; i++) {
            mTabLayout.addTab(mTabLayout.newTab().setText(strings[i]));
        }
    }

    //联动的监听
    private void setListener() {
        mTabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                mViewPager.setCurrentItem(position);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        mViewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener(){
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                mTabLayout.setScrollPosition(position,0,false);
            }
        });
        textViewLearn.setOnClickListener(this);
    }

    private void setAdapter() {
        //设置适配器
        adapter=new SecViewPagerAdapter(getSupportFragmentManager(),fragments,strings);
        mViewPager.setAdapter(adapter);
        mTabLayout.setupWithViewPager(mViewPager);
        mViewPager.setOffscreenPageLimit(2);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


    @Override
    public void onClick(View v) {
        study();

    }
    public void study(){
        MJsonHttpResponseHandler handler=new MJsonHttpResponseHandler(AcademyPlayActivity.class){
            @Override
            public void onGoodResponse(JSONObject response) {
                super.onGoodResponse(response);
                textViewLearn.setText("正在学习中");
            }

            @Override
            public void onBadResponse(JSONObject response) {
                super.onBadResponse(response);
                int i = response.optInt("i");
                if(i==37505){
                    textViewLearn.setText("正在学习中");
                    return;
                }else if(i==37504){
                    GaiaApp.showToast("你还为购买该教程,请用电脑登录购买");
                }
            }
        };

        AcademyApiHelper.stareStudy(cid,getApplicationContext(),handler);
    }
    public void study1(){
        MJsonHttpResponseHandler handler=new MJsonHttpResponseHandler(AcademyPlayActivity.class){
            @Override
            public void onGoodResponse(JSONObject response) {
                super.onGoodResponse(response);
                textViewLearn.setText("正在学习中");
            }

            @Override
            public void onBadResponse(JSONObject response) {
                super.onBadResponse(response);
                int i = response.optInt("i");
                if(i==37505){
                    textViewLearn.setText("正在学习中");
                }
            }
        };
        AcademyApiHelper.stareStudy(cid,getApplicationContext(),handler);
    }
}
