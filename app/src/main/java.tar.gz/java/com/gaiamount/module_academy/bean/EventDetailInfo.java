package com.gaiamount.module_academy.bean;

/**
 * Created by yukun on 16-8-4.
 */
public class EventDetailInfo {
    public String intr;
    public String sofeware;
    public long id;
    public long cid;
    public EventDetailInfo(String Intr, String sofeware, long id, long cid){
        this.intr=Intr;
        this.sofeware=sofeware;
        this.id=id;
        this.cid=cid;
    }
}
