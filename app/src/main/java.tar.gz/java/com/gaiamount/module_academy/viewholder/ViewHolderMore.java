package com.gaiamount.module_academy.viewholder;

import android.media.Image;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.gaiamount.R;

/**
 * Created by yukun on 16-8-2.
 */
public class ViewHolderMore extends RecyclerView.ViewHolder {
    public TextView textViewIntroduce,textViewPrice,textViewTime,textViewLearn;
    public ImageView imageViewImg, imageViewDevide;
    public ViewHolderMore(View itemView) {
        super(itemView);
        textViewIntroduce= (TextView) itemView.findViewById(R.id.academy_introduce);
        textViewPrice= (TextView) itemView.findViewById(R.id.academy_price);
        textViewTime= (TextView) itemView.findViewById(R.id.academy_time);
        textViewLearn= (TextView) itemView.findViewById(R.id.academy_textview_learn);
        imageViewImg= (ImageView) itemView.findViewById(R.id.academy_img_map);
        imageViewDevide= (ImageView) itemView.findViewById(R.id.academy_devide);
    }
}
