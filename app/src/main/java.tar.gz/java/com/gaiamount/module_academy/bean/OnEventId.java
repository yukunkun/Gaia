package com.gaiamount.module_academy.bean;

/**
 * Created by yukun on 16-8-4.
 */
public class OnEventId {
    public int id;
    public OnEventId(int id){
        this.id=id;
    }
}
