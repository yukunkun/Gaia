package com.gaiamount.module_academy.bean;

/**
 * Created by yukun on 16-8-4.
 */
public class CollegeInfo {

    /**
     * name : MiXingLight
     * cover2 : b.jpg
     * description : 我的学院是这个
     * cover1 : a.jpg
     * id : 2
     * cover5 : e.jpg
     * cover4 : d.jpg
     * cover3 : c.jpg
     */

    private String name;
    private String cover2;
    private String description;
    private String cover1;
    private int id;
    private String cover5;
    private String cover4;
    private String cover3;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCover2() {
        return cover2;
    }

    public void setCover2(String cover2) {
        this.cover2 = cover2;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCover1() {
        return cover1;
    }

    public void setCover1(String cover1) {
        this.cover1 = cover1;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCover5() {
        return cover5;
    }

    public void setCover5(String cover5) {
        this.cover5 = cover5;
    }

    public String getCover4() {
        return cover4;
    }

    public void setCover4(String cover4) {
        this.cover4 = cover4;
    }

    public String getCover3() {
        return cover3;
    }

    public void setCover3(String cover3) {
        this.cover3 = cover3;
    }
}
