package com.gaiamount.module_academy.viewholder;

import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.gaiamount.R;

/**
 * Created by yukun on 16-8-2.
 */
public class ViewPager2Holder extends RecyclerView.ViewHolder {
    public ViewPager viewPager;
    public ViewPager2Holder(View itemView) {
        super(itemView);
        viewPager= (ViewPager) itemView.findViewById(R.id.academy_viewpager);
    }
}
