package com.gaiamount.module_academy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import com.gaiamount.R;
import com.gaiamount.apis.api_academy.AcademyApiHelper;
import com.gaiamount.module_academy.adapter.AcademyAdapter;
import com.gaiamount.module_academy.bean.OnEventId;
import com.gaiamount.util.ActivityUtil;
import com.gaiamount.util.network.MJsonHttpResponseHandler;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * kun 学院首页
 */
public class AcademyActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private AcademyAdapter adapter;
    private LinearLayoutManager linearLayoutManager;
    private ArrayList<String> covers=new ArrayList<>();
    private int id=0;
    private boolean tag=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_academy);

        initView();
        getInfo();
        setAdapter();
        setListener();
    }

    private void initView() {
        linearLayoutManager = new LinearLayoutManager(this);
        mRecyclerView= (RecyclerView) findViewById(R.id.academy_recyclerview);
        mRecyclerView.setLayoutManager(linearLayoutManager);
    }

    private void getInfo() {
        MJsonHttpResponseHandler handler=new MJsonHttpResponseHandler(AcademyActivity.class){
            @Override
            public void onGoodResponse(JSONObject response) {
                super.onGoodResponse(response);
                parasJson(response);
                tag=true;
            }
        };
        AcademyApiHelper.getCollege(handler);

    }

    private void parasJson(JSONObject response) {

        JSONObject o = response.optJSONObject("o");
        JSONArray college = o.optJSONArray("college");
        for (int i = 0; i < college.length(); i++) {
            JSONObject jsonObject = college.optJSONObject(i);
            String cover1 = jsonObject.optString("cover1");
            covers.add(cover1);
            String cover2 = jsonObject.optString("cover2");
            covers.add(cover2);
            String cover3 = jsonObject.optString("cover3");
            covers.add(cover3);
            String cover4 = jsonObject.optString("cover4");
            covers.add(cover4);
            String cover5 = jsonObject.optString("cover5");
            covers.add(cover5);
            id=jsonObject.optInt("id");
        }
        EventBus.getDefault().post(new OnEventId(id));
        adapter.notifyDataSetChanged();
    }

    private void setAdapter() {
        adapter = new AcademyAdapter(getApplicationContext(),id,covers);
        mRecyclerView.setAdapter(adapter);
    }


    private void setListener() {
        mRecyclerView.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
//                int lastVisibleItemPosition = linearLayoutManager.findLastCompletelyVisibleItemPosition();
//                if (lastVisibleItemPosition == linearLayoutManager.getItemCount()-1) {
//                    //加载更多
//                    adapter.notifyDataSetChanged();
//                }
            }
        });
    }


    //返回

    public void AcademyBack(View view) {
        finish();
    }

    public void AcademySearch(View view) {
//        ActivityUtil.startCreatorSearchActivity(AcademyActivity.this);
    }
}
