package com.gaiamount.module_academy.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.Toast;

import com.gaiamount.R;
import com.gaiamount.apis.api_academy.AcademyApiHelper;
import com.gaiamount.module_academy.activity.AcademyPlayActivity;
import com.gaiamount.module_academy.adapter.ExpandableAdapter;
import com.gaiamount.module_academy.bean.Contents;
import com.gaiamount.module_academy.bean.EventDetailInfo;
import com.gaiamount.module_academy.bean.LessonInfo;
import com.gaiamount.module_im.secret_chat.bean.ContentInfo;
import com.gaiamount.util.ActivityUtil;
import com.gaiamount.util.network.MJsonHttpResponseHandler;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Created by yukun on 16-8-3.
 */
public class ContentFragment extends Fragment {

    private ExpandableListView expandableListView;
    private ExpandableAdapter expandableAdapter;
    private long id;
    private long cid;
    private ArrayList<ArrayList<Double>> processList=new ArrayList<>();
    private ArrayList<Contents> contentList=new ArrayList<>();
    private ArrayList<ArrayList<LessonInfo>> lessonList=new ArrayList<>();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EventBus.getDefault().register(this);
    }
    //页面的回调,传值id
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(EventDetailInfo event) {
        id = event.id;
        cid = event.cid;
        getInfo(id);
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View inflate = inflater.inflate(R.layout.contant_fragment, null);
        init(inflate);
        setAdapter();
        setListener();
        return inflate;
    }



    private void init(View inflate) {
        expandableListView = (ExpandableListView) inflate.findViewById(R.id.contant_expandableliustview);

    }

    private void getInfo(long id) {
        MJsonHttpResponseHandler handler=new MJsonHttpResponseHandler(ContentFragment.class){
            @Override
            public void onGoodResponse(JSONObject response) {
                super.onGoodResponse(response);
                paraJson(response);
            }
        };
        AcademyApiHelper.getContent(id,getContext(),handler);
    }

    private void paraJson(JSONObject response) {
        JSONArray a = response.optJSONArray("a");
        for (int i = 0; i < a.length(); i++) {
            Contents info=new Contents();
            //章节的数据
            JSONObject object = a.optJSONObject(i);
            JSONObject chapter = object.optJSONObject("chapter");
            info.setName(chapter.optString("name"));
            info.setInd(chapter.optInt("ind"));
            info.setChapterId(chapter.optLong("id"));
            contentList.add(info);
            //添加已播放的数据
            JSONArray process = object.optJSONArray("process");
            ArrayList<Double> doubles=new ArrayList<>();
            for (int k = 0; k < process.length(); k++) {
                double i1 = process.optDouble(k);
                doubles.add(i1);
            }
            processList.add(doubles);
            //节数的数据
            JSONArray hour = object.optJSONArray("hour");
            ArrayList<LessonInfo> lessonInfos=new ArrayList<>();
            for (int j = 0; j <hour.length() ; j++) {
                LessonInfo lessonInfo=new LessonInfo();
                JSONObject jsonObject = hour.optJSONObject(j);
                lessonInfo.setName(jsonObject.optString("name"));
                lessonInfo.setId(jsonObject.optInt("id"));
                lessonInfo.setScreenshot(jsonObject.optString("screenshot"));
                lessonInfos.add(lessonInfo);
            }
            lessonList.add(lessonInfos);
        }
        setOpen();
        expandableAdapter.notifyDataSetChanged();
    }

    private void setAdapter() {
        expandableAdapter = new ExpandableAdapter(getContext(),contentList,lessonList,processList);
        expandableListView.setAdapter(expandableAdapter);


    }

    private void setListener() {

        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {

                ArrayList<Integer> longHid=new ArrayList<Integer>();
                for (int i = 0; i <lessonList.get(groupPosition).size() ; i++) {
                    int hid = lessonList.get(groupPosition).get(childPosition).getId();
                    longHid.add(hid);
                }
                //开启视频播放页
                ActivityUtil.startAcademyPlayActivity(cid,childPosition,contentList.get(groupPosition).getChapterId()
                        ,longHid,getContext());

                return false;
            }
        });
    }

    //默认打开
    public void setOpen(){

        for(int i = 0; i < expandableAdapter.getGroupCount(); i++){
            expandableListView.expandGroup(i);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }
}
