package com.gaiamount.module_down_up_load.upload.upload_bean;

/**
 * Created by haiyang-lu on 16-6-2.
 */
public class ChooseCategoryItem {
    public String name;

    public boolean isChecked;

    public ChooseCategoryItem(String name, boolean isChecked) {
        this.name = name;
        this.isChecked = isChecked;
    }
}
