package com.gaiamount.module_down_up_load.upload.upload_bean;

/**
 * Created by haiyang-lu on 16-3-17.
 */
public class UploadType {
    public static final int VIDEO_TYPE = 1;
    public static final int WORK_INFO = 2;
    public static final int CHOOSE_CATEGORY = 3;
    public static final int SET_TAG = 4;
    public static final int DOWNLOAD_SET = 5;
    public static final int BACK_STORY = 6;
    public static final int ADD_TO_SPECIAL = 7;
    public static final int ADD_TO_GROUP = 8;
    public static final int ADD_WATERMARK = 9;

}
