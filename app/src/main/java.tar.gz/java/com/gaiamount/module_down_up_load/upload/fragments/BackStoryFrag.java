package com.gaiamount.module_down_up_load.upload.fragments;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.gaiamount.R;
import com.gaiamount.module_down_up_load.upload.upload_bean.UploadType;

/**
 * Created by haiyang-lu on 16-6-1.
 */
public class BackStoryFrag extends BaseUploadFrag {

    private EditText mEditText;

    @Override
    protected void setTitle(TextView title) {
        title.setText(getResources().getString(R.string.back_story));
    }

    @Override
    protected void restore() {

    }

    @Override
    protected void setSaveBtn(TextView saveBtn) {
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFragmentStateChangeListener.onFinish(UploadType.BACK_STORY);
            }
        });
    }

    @Override
    protected View getContent() {
        return getInflater().inflate(R.layout.fragment_back_story,null);
    }

    @Override
    protected void initView(View content) {
        mEditText = (EditText) content.findViewById(R.id.edit_text);
    }
}
