package com.gaiamount.gaia_main.home;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.view.Menu;
import android.view.MenuItem;

import com.gaiamount.R;
import com.gaiamount.gaia_main.DrawerBaseActivity;
import com.gaiamount.gaia_main.GaiaApp;
import com.gaiamount.module_down_up_load.upload_manage.UploadManager;
import com.gaiamount.gaia_main.signin_signup.LoginActivity;
import com.gaiamount.util.ActivityUtil;

public class HomeActivity extends DrawerBaseActivity {
    /**
     * 2S内按下back键2次退出
     */
    private static final long BACK_PRESSED_TIME = 2000;
    /**
     * 主页fragment
     */
    private HomeFrag mHomeFrag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //父类方法
        initHeaderView();
        //父类方法
        updateUserData();
        //父类方法
        initToolbar();

        initContentView();

    }


    int backPressedTime = 0;
    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == 0) {
                backPressedTime = 0;
            }
        }
    };

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        //如果drawerLayout开着，则关闭
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            boolean isUploading = UploadManager.getInstance(getApplicationContext()).isUploading();
            if (isUploading) {
                AlertDialog.Builder builder = new AlertDialog.Builder(this)
                        .setMessage(R.string.upload_unfinished)
                        .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                UploadManager.getInstance(getApplicationContext()).cancelUpload();
                                HomeActivity.super.onBackPressed();
                            }
                        })
                        .setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //ignore
                            }
                        });
                builder.create().show();
            } else {
                //如果已经关闭，执行默认步骤
                backPressedTime++;
                handler.sendEmptyMessageDelayed(0, BACK_PRESSED_TIME);

                if (backPressedTime == 2) {
                    super.onBackPressed();
                } else {
                    GaiaApp.showToast(getString(R.string.click_before_exit));
                }
            }

        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_message) {
            ActivityUtil.startMessageActivity(this);
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == LoginActivity.REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            //用户登陆成功，更新界面 头像+用户基本信息
            updateUserData();
        }
    }


    private void initContentView() {
        if (mHomeFrag == null) {
            mHomeFrag = HomeFrag.newInstance();
        }
        getSupportFragmentManager().beginTransaction().add(R.id.main_content_container, mHomeFrag).commit();

    }

}
