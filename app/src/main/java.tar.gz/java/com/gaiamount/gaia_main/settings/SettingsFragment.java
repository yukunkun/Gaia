package com.gaiamount.gaia_main.settings;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;
import android.support.annotation.Nullable;

import com.gaiamount.R;
import com.gaiamount.gaia_main.GaiaApp;
import com.gaiamount.util.DataCleanManager;
import com.gaiamount.util.network.AppUtil;

/**
 * Created by haiyang-lu on 16-7-25.
 */
public class SettingsFragment extends PreferenceFragment {

    private SharedPreferences mPrefs;
    private SharedPreferences.OnSharedPreferenceChangeListener mListener;

    public static SettingsFragment newInstance() {

        Bundle args = new Bundle();

        SettingsFragment fragment = new SettingsFragment();
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.preference);
        mListener = new SharedPreferences.OnSharedPreferenceChangeListener() {
            @Override
            public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
                if (key.equals(getString(R.string.key_language))) {
                    //切换语言
                    Settings settings = Settings.newInstance(getActivity());
                    if (settings.getLanguage().equals(getResources().getStringArray(R.array.language_value)[0])) {//中文
                        AppUtil.changeLanguage(getActivity(), AppUtil.CHINESE);
                    } else if (settings.getLanguage().equals(getResources().getStringArray(R.array.language_value)[1])) {//英文
                        AppUtil.changeLanguage(getActivity(), AppUtil.ENGLISH);
                    }
                    //重启activity
                    getActivity().startActivity(new Intent().setClass(getActivity(), SettingsActivity.class));
                    getActivity().finish();
                }
            }
        };
        mPrefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
        mPrefs.registerOnSharedPreferenceChangeListener(mListener);
        //设置版本号
        Preference preference = getPreferenceScreen().findPreference(getString(R.string.key_version_update));
        preference.setSummary(Settings.newInstance(getActivity()).getVersionName());
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mListener != null && mPrefs != null) {
            mPrefs.unregisterOnSharedPreferenceChangeListener(mListener);
        }
    }

    @Override
    public boolean onPreferenceTreeClick(PreferenceScreen preferenceScreen, Preference preference) {
        String key = preference.getKey();
        if (getString(R.string.key_clean_cache).equals(key)) {
            DataCleanManager.cleanApplicationData(getActivity(), getActivity().getFilesDir().getAbsolutePath());
            GaiaApp.showToast(getString(R.string.clean_cache_finished));
        }

        return super.onPreferenceTreeClick(preferenceScreen, preference);
    }


}
