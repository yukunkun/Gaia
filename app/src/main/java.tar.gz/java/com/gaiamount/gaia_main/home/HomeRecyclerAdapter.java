package com.gaiamount.gaia_main.home;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import com.gaiamount.R;
import com.gaiamount.module_workpool.WorkRecBean;
import com.gaiamount.util.ActivityUtil;

import java.util.List;

/**
 * Created by haiyang-lu on 16-5-20.
 * home主页列表的适配器
 */
public class HomeRecyclerAdapter extends RecyclerView.Adapter<HomeRecyclerAdapter.MyViewHolder> {
    private String[] mTitles;
    private LayoutInflater inflater;
    private Context mContext;
    private List<WorkRecBean> mWorkRecBeanList;


    public HomeRecyclerAdapter(Context context, List<WorkRecBean> workRecBeanList) {
        mContext = context;
        mTitles = context.getResources().getStringArray(R.array.home_list_type);
        mWorkRecBeanList = workRecBeanList;
        inflater = LayoutInflater.from(context);

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View inflate = inflater.inflate(R.layout.item_square_grid, null, true);
        return new MyViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.title.setText(mTitles[position]);
        holder.mBtnMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //点击“更多”进入作品池
                ActivityUtil.startWorkPoolActivity(mContext);
            }
        });
        holder.gridView.setAdapter(new HomeGridAdapter(mContext,mWorkRecBeanList));

    }

    @Override
    public int getItemCount() {
        return mTitles.length;
    }


    class MyViewHolder extends RecyclerView.ViewHolder {
        /**
         * 标题 如作品推荐 素材推荐
         */
        TextView title;
        /**
         * “更多”按钮
         */
        Button mBtnMore;
        /**
         * 子项
         */
        GridView gridView;


        public MyViewHolder(View itemView) {
            super(itemView);
            title = (TextView) itemView.findViewById(R.id.title);
            mBtnMore = (Button) itemView.findViewById(R.id.btn_more);
            gridView = (GridView) itemView.findViewById(R.id.gv_recommend);
        }
    }


}