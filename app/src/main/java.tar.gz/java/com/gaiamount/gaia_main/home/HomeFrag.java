package com.gaiamount.gaia_main.home;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.bigkoo.convenientbanner.ConvenientBanner;
import com.bigkoo.convenientbanner.holder.CBViewHolderCreator;
import com.bigkoo.convenientbanner.holder.Holder;
import com.bigkoo.convenientbanner.listener.OnItemClickListener;
import com.bumptech.glide.Glide;
import com.gaiamount.R;
import com.gaiamount.apis.Configs;
import com.gaiamount.apis.api_works.WorksApiHelper;
import com.gaiamount.module_academy.activity.MixingLightActivity;
import com.gaiamount.module_workpool.WorkRecBean;
import com.gaiamount.util.ActivityUtil;
import com.gaiamount.util.network.MJsonHttpResponseHandler;
import com.gaiamount.widgets.RecyclerViewHeader2;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by luxiansheng on 16/3/6.
 * 主jpg4页fragment
 */
public class HomeFrag extends Fragment implements View.OnClickListener {

    public static final int AUTO_TURNING_TIME = 6000;
    private RecyclerView mWorkRec;
    private LinearLayout mLinearLayout;
    /**
     * 作品池模块图标
     */
    private ImageView mModule_work_pool;
    /**
     * 创作者模块图标
     */
    private ImageView mModuleCreator;
    /**
     * 学院图标
     */
    private ImageView mModule_Academy;
    private RecyclerViewHeader2 mHeader;
    private ConvenientBanner mConvenientBanner;

    public static HomeFrag newInstance() {
        HomeFrag homeFrag = new HomeFrag();
        return homeFrag;
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_home, container, false);

        initView(view);

        setUpView();


        getDataFromNet();//联网获取首页推荐数据

        return view;
    }

    @Override
    public void onPause() {
        super.onPause();
        mConvenientBanner.stopTurning();
    }

    @Override
    public void onResume() {
        super.onResume();
        mConvenientBanner.startTurning(AUTO_TURNING_TIME);
    }

    private void initView(View view) {
        mWorkRec = (RecyclerView) view.findViewById(R.id.work_rec);
        //添加头部
        mHeader = RecyclerViewHeader2.fromXml(getActivity(), R.layout.layout_main_header);
        mModule_work_pool = (ImageView) mHeader.findViewById(R.id.module_work_pool);
        mModuleCreator = (ImageView) mHeader.findViewById(R.id.module_creator);
        mConvenientBanner = (ConvenientBanner) mHeader.findViewById(R.id.convenientBanner);

        mLinearLayout = (LinearLayout) view.findViewById(R.id.home_fragment_linear);
        mModule_Academy = (ImageView) mHeader.findViewById(R.id.module_collage);

    }

    private void setUpView() {
        mModule_work_pool.setOnClickListener(this);
        mModuleCreator.setOnClickListener(this);
        mModule_Academy.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.module_work_pool://打开作品池
                ActivityUtil.startWorkPoolActivity(getActivity());
                break;
            case R.id.module_creator:
                ActivityUtil.startCreatorActivity(getActivity());
                break;
            case R.id.module_collage://学院
                Intent intent=new Intent(getContext(),MixingLightActivity.class);
                startActivity(intent);
                break;
        }
    }

    /**
     * 联网获取主页推荐数据
     */
    private void getDataFromNet() {
        int num = 17;
        JsonHttpResponseHandler jsonHttpResponseHandler = new MJsonHttpResponseHandler(HomeFrag.class) {
            @Override
            public void onGoodResponse(JSONObject response) {
                super.onGoodResponse(response);
                paresJson(response);
                mLinearLayout.setVisibility(View.GONE); //提示加载的progressbar隐藏

            }
        };
        WorksApiHelper.getRecommend(num, getActivity(), jsonHttpResponseHandler);
    }

    /**
     * 解析json并设置适配器
     *
     * @param response
     */
    private void paresJson(JSONObject response) {
        JSONArray jsonArray = response.optJSONArray("a");
        List<WorkRecBean> workRecBeanList = new Gson().fromJson(jsonArray.toString(), new TypeToken<List<WorkRecBean>>() {
        }.getType());
        //传入适配器并将适配器设置进列表
        LinearLayoutManager layout = new LinearLayoutManager(getActivity());
        mWorkRec.setLayoutManager(layout);
        mWorkRec.setAdapter(new HomeRecyclerAdapter(getActivity(), workRecBeanList.subList(5,17)));
        mHeader.attachTo(mWorkRec);

        //准备广告条数据
        final List<WorkRecBean> subList = workRecBeanList.subList(0, 5);
        List<String> bannerImages = new ArrayList<>();
        for (int i = 0; i < subList.size(); i++) {
            String url = subList.get(i).getScreenshot();
            if (url != null) {
                url = Configs.COVER_PREFIX + url.replace(".", "_18.");
                bannerImages.add(i, url);
            }

        }
        //加载广告条
        mConvenientBanner.setPages(new CBViewHolderCreator<NetworkImageHolderView>() {
            @Override
            public NetworkImageHolderView createHolder() {
                return new NetworkImageHolderView();
            }
        }, bannerImages)
                //设置两个点图片作为翻页指示器，不设置则没有指示器，可以根据自己需求自行配合自己的指示器,不需要圆点指示器可用不设
                .setPageIndicator(new int[]{R.drawable.ic_page_indicator, R.drawable.ic_page_indicator_focused})
                //设置指示器的方向
                .setPageIndicatorAlign(ConvenientBanner.PageIndicatorAlign.ALIGN_PARENT_RIGHT);
        mConvenientBanner.startTurning(AUTO_TURNING_TIME);
        mConvenientBanner.setCanLoop(true);
        mConvenientBanner.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                //进入播放页
                WorkRecBean workRecBean = subList.get(position);
                ActivityUtil.startPlayerActivity(getActivity(),workRecBean.getId(),Configs.TYPE_WORK_POOL,mConvenientBanner);
            }
        });
    }

    public class NetworkImageHolderView implements Holder<String> {
        private ImageView imageView;

        @Override
        public View createView(Context context) {
            imageView = new ImageView(context);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            return imageView;
        }

        @Override
        public void UpdateUI(Context context, final int position, String data) {
            Glide.with(HomeFrag.this).load(data).into(imageView);
        }
    }
}
