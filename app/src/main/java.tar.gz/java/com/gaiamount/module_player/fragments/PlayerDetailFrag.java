package com.gaiamount.module_player.fragments;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.gaiamount.R;
import com.gaiamount.apis.api_creator.PersonApiHelper;
import com.gaiamount.apis.api_works.WorksApiHelper;
import com.gaiamount.gaia_main.GaiaApp;
import com.gaiamount.module_player.bean.VideoDetailInfo;
import com.gaiamount.util.ActivityUtil;
import com.gaiamount.util.StringUtil;
import com.gaiamount.util.image.ImageUtils;
import com.gaiamount.util.network.MJsonHttpResponseHandler;
import com.google.gson.Gson;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONObject;

/**
 * Created by haiyang-lu on 16-4-5.
 */
public class PlayerDetailFrag extends Fragment implements View.OnClickListener {

    public static final String DETAIL_INFO = "detail_info";
    public static final String WID = "wid";
    private VideoDetailInfo detailInfo;
    private StringUtil mStringUtil;
    private RatingBar mRatingBar;
    private TextView mScore;
    private long mWid;
    private Button mAdd_attention;
    /**
     * 点击关注/取消关注
     */
    private View.OnClickListener addAttentionClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (isAttentioned) {
                PersonApiHelper.addAttention(detailInfo.getUser().getUid(), 0, getActivity());
            }else {
                PersonApiHelper.addAttention(detailInfo.getUser().getUid(), 1, getActivity());
            }
            PersonApiHelper.isAttentioned(detailInfo.getUser().getUid(), getActivity());

        }
    };
    private PersonApiHelper.EventIsAttention mEventIsAttention;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        detailInfo = (VideoDetailInfo) getArguments().getSerializable("video_detail_info");
        mStringUtil = StringUtil.getInstance();
    }

    public static PlayerDetailFrag newInstance(VideoDetailInfo detailInfo, long wid) {

        Bundle args = new Bundle();
        args.putSerializable(DETAIL_INFO, detailInfo);
        args.putLong(WID, wid);
        PlayerDetailFrag fragment = new PlayerDetailFrag();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EventBus.getDefault().register(this);
        Bundle arguments = getArguments();
        mWid = arguments.getLong(WID);
        detailInfo = (VideoDetailInfo) arguments.getSerializable(DETAIL_INFO);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tab_detail, container, false);
        initView(view);

        //判断当前视频的作者是否被关注了
        PersonApiHelper.isAttentioned(detailInfo.getUser().getUid(), getActivity());

        return view;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    /**
     * 当前被查看的视频的作者是否被当前用户关注的回调
     * @param eventIsAttention
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventIsAttentioned(PersonApiHelper.EventIsAttention eventIsAttention) {
        mEventIsAttention = eventIsAttention;
        int a = eventIsAttention.getA();
        if (a == 1) {//已关注
            isAttentioned = true;
            mAdd_attention.setTextColor(getResources().getColor(R.color.white));
            mAdd_attention.setText(R.string.have_attention);
            mAdd_attention.setBackgroundResource(R.drawable.shape_radius4_redstroke_whitebg);
        } else {
            mAdd_attention.setTextColor(getResources().getColor(R.color.colorAccent));
            isAttentioned = false;
            mAdd_attention.setText(R.string.add_attention);
            mAdd_attention.setBackgroundResource(R.drawable.shape_btn_style2);
        }
    }

    /**
     * 关注/取消关注成功的回调
     * @param eventAddAttention
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventAddAttention(PersonApiHelper.EventAddAttention eventAddAttention) {
        isAttentioned = !isAttentioned;
        if (isAttentioned) {
            GaiaApp.showToast(getString(R.string.add_attention_success));
        }else {
            GaiaApp.showToast(getString(R.string.cancel_attention_success));
        }
        PersonApiHelper.isAttentioned(detailInfo.getUser().getUid(), getActivity());
    }


    private void initView(View view) {
        TextView name_director_quality = (TextView) view.findViewById(R.id.name_director_quality);
        TextView playcount_playtime = (TextView) view.findViewById(R.id.playcount_playtime);
        mScore = (TextView) view.findViewById(R.id.score);
        mRatingBar = (RatingBar) view.findViewById(R.id.play_grade_rating);
        TextView master = (TextView) view.findViewById(R.id.master);
        TextView tag = (TextView) view.findViewById(R.id.tag);
        TextView back_story = (TextView) view.findViewById(R.id.back_story);

        ImageView avatar = (ImageView) view.findViewById(R.id.avatar);
        mAdd_attention = (Button) view.findViewById(R.id.add_attention);
        TextView staff = (TextView) view.findViewById(R.id.staff);

        if (detailInfo != null) {
            VideoDetailInfo.WorksBean works = detailInfo.getWorks();
            VideoDetailInfo.VideoInfoBean videoInfo = detailInfo.getVideoInfo();
            //作品名称|作者名称|作品质量
//            name_director_quality.setText(works.getName()+"|"+works.getDirector()+"|"+(works.getIs4K()==1?"4K":""));
            name_director_quality.setText(works.getName());
            //播放次数，和上传的时间
            playcount_playtime.setText(mStringUtil.stringForCount(detailInfo.getWorksProperties().getPlayCount()));
            //评分
            setGrade();
            //staff
            StringBuilder staffStr = new StringBuilder();
            staffStr.append("导演:" + works.getDirector() + "|");
            staffStr.append("摄影:" + works.getPhotographer() + "|");
            staffStr.append("剪辑:" + works.getCutter() + "|");
            staffStr.append("调色:" + works.getColorist() + "|");
            staffStr.append("机型:" + works.getMachine() + "|");
            staffStr.append("镜头:" + works.getLens() + "|");
            staffStr.append("地点:" + works.getAddress() + "|");
            staffStr.append("场景:" + works.getScene() + "|");
            staffStr.append("分辨率:" + videoInfo.getWidth() + "x" + videoInfo.getHeight() + "|");
            staffStr.append("格式:" + videoInfo.getFormat() + "|");
            staffStr.append("编码:" + videoInfo.getCodec() + "|");
            staffStr.append("码率:" + mStringUtil.stringForBitrate(videoInfo.getBitRate()) + "|");
            String[] strings = videoInfo.getFps().split("/");
            if (!strings[0].isEmpty() && !strings[1].isEmpty()) {
                double v = Double.parseDouble(strings[0]) / Double.parseDouble(strings[1]);
                Double aDouble = Double.valueOf(v);
                int i = aDouble.intValue();
                if (v == i) {
                    staffStr.append("帧率:" + i + "|");
                } else {
                    staff.append("帧率:" + String.format("%.2f", v));
                }
            }


            staffStr.append("大小:" + mStringUtil.stringForSize(videoInfo.getSize()) + "|");
            staff.setText(staffStr);
            //作品标签
            SpannableStringBuilder tagStr = new SpannableStringBuilder("作品标签:" + works.getKeywords());
            tagStr.setSpan(new ForegroundColorSpan(Color.parseColor("#444444")), 0, 5, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
            tag.setText(tagStr);
            //作品背景
            String description = works.getDescription();
            Spanned spanned = Html.fromHtml(description);
            SpannableStringBuilder workBg = new SpannableStringBuilder("作品背景:" + spanned);
            workBg.setSpan(new ForegroundColorSpan(Color.parseColor("#444444")), 0, 5, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
            back_story.setText(workBg);

            //头像
            VideoDetailInfo.UserBean user = detailInfo.getUser();
            if (user.getAvatar() != null) {
                ImageUtils.getInstance(getActivity()).getAvatar(avatar, user.getAvatar());
            }
            avatar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ActivityUtil.startPersonalActivity(getActivity(), detailInfo.getUser().getUid());
                }
            });
            //作者名称
            master.setText(user.getNickName());
        }

        mRatingBar.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                openGradeDialog();
                return false;
            }
        });


        if (mAdd_attention != null) {
            mAdd_attention.setOnClickListener(addAttentionClickListener);
        }

    }

    private boolean isAttentioned = false;

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.score:
                openGradeDialog();
                break;
            default:
                break;
        }
    }

    /**
     * 打开打分对话框
     */
    private void openGradeDialog() {
        //打分对话框
        double grade = detailInfo.getWorks().getGrade();
        GradeDialogFrag gradeDialogFrag = GradeDialogFrag.newInstance(mWid, grade);
        gradeDialogFrag.show(getActivity().getSupportFragmentManager(), "grade");
        gradeDialogFrag.setOnGradeChangeListener(new GradeDialogFrag.OnGradeChangeListener() {
            @Override
            public void onGradeChange(double grade) {
                getNewData();
            }
        });
    }

    private void getNewData() {
        JsonHttpResponseHandler handler = new MJsonHttpResponseHandler(PlayerDetailFrag.class) {
            @Override
            public void onGoodResponse(JSONObject response) {
                super.onGoodResponse(response);
                //解析json并将新值赋给detailInfo
                detailInfo = new Gson().fromJson(response.optJSONObject("o").toString(), VideoDetailInfo.class);
                //更新界面
                setGrade();
            }
        };
        WorksApiHelper.getDetailWorkInfo(mWid, getActivity(), handler);
    }

    private void setGrade() {
        //评分
        double grade = detailInfo.getWorks().getGrade();
        mScore.setText(String.valueOf(grade));
        mScore.setOnClickListener(this);
        //星级评分条
        mRatingBar.setRating((float) (grade / 2));
    }
}
