package com.gaiamount.module_player;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewStub;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.gaiamount.R;
import com.gaiamount.apis.Configs;
import com.gaiamount.apis.api_works.WorksApiHelper;
import com.gaiamount.gaia_main.GaiaApp;
import com.gaiamount.gaia_main.history.HistoryDBManager;
import com.gaiamount.module_player.adapters.PlayerViewPagerAdapter;
import com.gaiamount.module_player.bean.VideoDetailInfo;
import com.gaiamount.module_player.dialogs.AddToDialog;
import com.gaiamount.module_player.fragments.PlayerColFrag;
import com.gaiamount.module_player.fragments.PlayerCommentFrag;
import com.gaiamount.module_player.fragments.PlayerDetailFrag;
import com.gaiamount.module_player.fragments.PlayerDownloadFrag;
import com.gaiamount.module_player.fragments.PlayerRecFrag;
import com.gaiamount.module_player.fragments.PlayerTipOffFrag;
import com.gaiamount.util.ActivityUtil;
import com.gaiamount.util.ShareUtil;
import com.gaiamount.util.image.ImageUtils;
import com.gaiamount.util.network.MJsonHttpResponseHandler;
import com.gaiamount.widgets.media.GMediaController;
import com.gaiamount.widgets.media.GVideoView;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import fr.castorflex.android.circularprogressbar.CircularProgressBar;
import tv.danmaku.ijk.media.player.IMediaPlayer;
import tv.danmaku.ijk.media.player.IjkMediaPlayer;

public class VideoActivity extends AppCompatActivity {
    private static final String TAG = "VideoActivity";
    public static final String TYPE = "type";
    public static final String WORK_ID = "work_id";

    private int mWorkId;
    private int mContentType;

    private View mDecorView;
    private GMediaController mMediaController;
    private GVideoView mVideoView;

    private Drawable mDb_collection;
    private VideoDetailInfo mDetailInfo;
    private TextView mTitle;
    private VolumeBroadCastReceiver mVolumeReceiver;
    private HistoryDBManager mManager;

    @Bind(R.id.progressBar)
    CircularProgressBar mProgressBar;


    private IMediaPlayer.OnInfoListener onInfoListener = new IMediaPlayer.OnInfoListener() {
        @Override
        public boolean onInfo(IMediaPlayer mp, int what, int extra) {
            switch (what) {
                case IMediaPlayer.MEDIA_INFO_BUFFERING_START:
                    mProgressBar.setVisibility(View.VISIBLE);
                    break;
                case IMediaPlayer.MEDIA_INFO_BUFFERING_END:
                    mProgressBar.setVisibility(View.GONE);
                    break;
            }
            return false;
        }
    };
    private IMediaPlayer.OnPreparedListener onPreparedListener = new IMediaPlayer.OnPreparedListener() {
        @Override
        public void onPrepared(IMediaPlayer mp) {
            mProgressBar.setVisibility(View.GONE);
        }
    };
    private IMediaPlayer.OnCompletionListener onComplietionListener = new IMediaPlayer.OnCompletionListener() {
        @Override
        public void onCompletion(IMediaPlayer mp) {
            mMediaController.stop();

            //准备图片
            ImageUtils.convertToBlur(VideoActivity.this,mDetailInfo.getVideoInfo().getScreenshot(),mDetailInfo.getWorks().getCover());

            final ViewStub viewStub = (ViewStub) findViewById(R.id.replay);
            if (viewStub!=null) {
                viewStub.inflate();
                mReplayWrapper = (FrameLayout) findViewById(R.id.replay_wrapper);
                ImageView ivReplay = (ImageView) findViewById(R.id.ic_replay);
                ivReplay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mVideoView.start();
                        mVideoView.seekTo(0);
                        mReplayWrapper.setVisibility(View.GONE);
                    }
                });
            }else {
                mReplayWrapper.setVisibility(View.VISIBLE);
            }
        }
    };
    private FrameLayout mReplayWrapper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);
        ButterKnife.bind(this);
        mDecorView = getWindow().getDecorView();
        // handle arguments
        mWorkId = getIntent().getIntExtra(WORK_ID, -1);
        mContentType = getIntent().getIntExtra(TYPE, -1);

        //做一些初始化的操作
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        initToolBar(toolbar);
        mMediaController = new GMediaController(this);
        mMediaController.setToolbar(toolbar);

        // init player
        IjkMediaPlayer.loadLibrariesOnce(null);
        IjkMediaPlayer.native_profileBegin("libijkplayer.so");

        mVideoView = (GVideoView) findViewById(R.id.gaia_video_view);
        mVideoView.setMediaController(mMediaController);
        //设置监听
        mVideoView.setOnInfoListener(onInfoListener);
        mVideoView.setOnPreparedListener(onPreparedListener);
        mVideoView.setOnCompletionListener(onComplietionListener);
        //～～～～～～～～

        VideoUtil videoUtil = new VideoUtil();
        //获取视频详细信息
        videoUtil.getVideoInfo(this, mWorkId);

        //注册到事件总线
        EventBus.getDefault().register(this);

        mVolumeReceiver = new VolumeBroadCastReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.media.VOLUME_CHANGED_ACTION");
        registerReceiver(mVolumeReceiver, filter);

        //是否已收藏
        isCollected();
    }


    @Override
    public void onBackPressed() {
        if (mMediaController.isFullScreen()) {
            mMediaController.switchPortrait();
        } else {
            super.onBackPressed();
            mVideoView.stopPlayback();
            mVideoView.release(true);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        mVideoView.start();
        mMediaController.updatePausePlay();
    }


    @Override
    protected void onStop() {
        super.onStop();
        mVideoView.pause();
        mMediaController.updatePausePlay();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mVideoView.stopPlayback();
        mVideoView.release(true);
        //注销
        EventBus.getDefault().unregister(this);
        //解注册
        unregisterReceiver(mVolumeReceiver);
        //释放数据库资源
        if (mManager != null) {
            mManager.closeDB();
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            mMediaController.updateSwitch(true);
        } else {
            mMediaController.updateSwitch(false);
        }
    }

    /**
     * 是否被收藏了
     */
    private boolean isCollected = false;
    private final Handler mHandler = new Handler();


    private void isCollected() {
        MJsonHttpResponseHandler handler = new MJsonHttpResponseHandler(VideoActivity.class) {
            @Override
            public void onGoodResponse(JSONObject response) {
                super.onGoodResponse(response);
                int a = response.optInt("a");
                if (a == 1) {
                    isCollected = true;
                    mDb_collection.setColorFilter(getResources().getColor(R.color.colorAccent), PorterDuff.Mode.SRC_IN);
                } else {
                    isCollected = false;
                    mDb_collection.setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_IN);
                }

            }
        };
        WorksApiHelper.isCollected(mWorkId, this, handler);
    }

    /**
     * 收藏作品的开关
     *
     * @param collection 0 取消收藏 1收藏
     * @param drawable   收藏按钮的drawable对象 用于着色
     */
    private void collectionWorksToggle(final int collection, final Drawable drawable) {
        //作品类型
        ProgressDialog progressDialog = ProgressDialog.show(this, null, getString(R.string.dealing));
        JsonHttpResponseHandler jsonHttpResponseHandler = new MJsonHttpResponseHandler(VideoActivity.class, progressDialog) {
            @Override
            public void onGoodResponse(JSONObject response) {
                super.onGoodResponse(response);
                //改变收藏图标颜色
                if (collection == 1) {
                    isCollected = true;

                    //红色
                    drawable.setColorFilter(getResources().getColor(R.color.colorAccent), PorterDuff.Mode.SRC_IN);
                    //显示成功收藏
                    final PlayerColFrag playerColFrag = PlayerColFrag.newInstance();
                    playerColFrag.show(getSupportFragmentManager(), "collection");
                    //3s后隐藏界面
                    mHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            //自动隐藏
                            playerColFrag.dismiss();
                        }
                    }, 1500);
                } else {
                    isCollected = false;
                    //白色
                    drawable.setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_IN);
                    //toast
                    GaiaApp.showToast(getString(R.string.cancel_collection_success));
                }

            }
        };
        WorksApiHelper.collect(mWorkId, mContentType, collection, this, jsonHttpResponseHandler);
    }

    /**
     * 初始化actionBar
     *
     * @param toolbar
     */
    private void initToolBar(Toolbar toolbar) {
        toolbar.setTitle("");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        toolbar.inflateMenu(R.menu.menu_player);
        MenuItem item_coll = toolbar.getMenu().findItem(R.id.action_collection);
        mDb_collection = item_coll.getIcon();
        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == android.R.id.home) {
                    finish();
                } else if (itemId == R.id.action_tip_off) {
                    //去举报
                    long wid = mDetailInfo.getResource().getFid();
                    PlayerTipOffFrag playerTipOffFrag = PlayerTipOffFrag.newInstance(wid);
                    playerTipOffFrag.show(getSupportFragmentManager(), "tip_off");
                } else if (itemId == R.id.action_collection) {
                    //收藏/取消收藏作品
                    if (isCollected) {//已经收藏，则取消收藏
                        collectionWorksToggle(0, mDb_collection);
                    } else {
                        collectionWorksToggle(1, mDb_collection);
                    }
                } else if (itemId == R.id.action_download) {
                    //显示下载选项
                    PlayerDownloadFrag playerDownloadFrag = PlayerDownloadFrag.newInstance(mDetailInfo, mWorkId, mContentType);
                    playerDownloadFrag.show(getSupportFragmentManager(), "download");
                } else if (itemId == R.id.action_work_setting) {
                    long userId = mDetailInfo.getUser().getUid();

                    //判断是否是原作者
                    if (userId == GaiaApp.getUserInfo().id) {
                        ActivityUtil.startWorkSettingActivity(VideoActivity.this, mWorkId, mContentType);
                    } else {
                        GaiaApp.showToast(getString(R.string.no_power));
                    }

                } else if (itemId == R.id.action_share) {
                    ShareUtil.newInstance(VideoActivity.this).startShare("Gaiamount", "http://www.gaiamount.com", "mDetailInfo.getWorks().getName()",
                            Configs.COVER_PREFIX + mDetailInfo.getVideoInfo().getScreenshot());
                } else if (itemId == R.id.action_add_to_group) {
                    //添加到...
                    long vid = mWorkId;
                    int vType = mContentType;
                    AddToDialog.newInstance(vid, vType).show(getSupportFragmentManager(), "add_to_group_or_album");

                }
                return true;
            }
        });
        mTitle = (TextView) toolbar.findViewById(R.id.title);
        mTitle.requestFocus();

    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventAfterGetData(VideoUtil.OnVideoInfoGettedEvent event) {
        mDetailInfo = event.getDetailInfo();

        //判断是否需要输入密码
        int requirePassword = mDetailInfo.getWorksPermission().getRequirePassword();
        if (requirePassword==1) {

        }

        //设置标题
        if (mTitle != null)
            mTitle.setText(mDetailInfo.getWorks().getName());

        String defaultUri = event.getDefaultPath();

        mVideoView.setVideoURI(Uri.parse(defaultUri));
        //下面两句顺序不能对调
        mMediaController.setDefaultUri(defaultUri);
        mMediaController.setVideoInfo(mDetailInfo);
        //将视频信息传给Controller
        //设置底下三个Fragment
        Bundle bundle = new Bundle();
        bundle.putSerializable("video_detail_info", mDetailInfo);
        bundle.putInt("contentType", mContentType);
        bundle.putLong("contentId", mWorkId);

        PlayerCommentFrag commentFrag = new PlayerCommentFrag();
        PlayerRecFrag playerRecFrag = new PlayerRecFrag();

        commentFrag.setArguments(bundle);
        playerRecFrag.setArguments(bundle);
        List<Fragment> fragmentList = new ArrayList<>();
        fragmentList.add(PlayerDetailFrag.newInstance(mDetailInfo, mWorkId));
        fragmentList.add(commentFrag);
        fragmentList.add(playerRecFrag);

        if (mDecorView != null) {
            ViewPager viewPager = (ViewPager) mDecorView.findViewById(R.id.video_player_vp);
            TabLayout tabLayout = (TabLayout) mDecorView.findViewById(R.id.video_player_tabs);

            viewPager.setAdapter(new PlayerViewPagerAdapter(getSupportFragmentManager(), fragmentList));
            tabLayout.setupWithViewPager(viewPager);
        }

        //添加到历史记录
        addToHistory();

    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventGetBlur(Bitmap bitmap) {
        BitmapDrawable bitmapDrawable = new BitmapDrawable(bitmap);
        mReplayWrapper.setBackground(bitmapDrawable);
    }

    private void addToHistory() {
        mManager = new HistoryDBManager(VideoActivity.this);
        mManager.add(mDetailInfo.getVideoInfo().getScreenshot(), mDetailInfo.getWorks().getCover(), mDetailInfo.getWorks().getName(), System.currentTimeMillis(),mWorkId,mContentType);
    }

    class VolumeBroadCastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            //更改声音控件的进度
            mMediaController.updateSoundProgress();
        }

    }

}
