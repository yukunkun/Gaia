package com.gaiamount.module_player;

import java.io.Serializable;

/**
 * 代表的是一个多媒体信息 可能是一个视频也可能是一个音频
 *
 */
public class MediaItem implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String name;

	private long duration;

	private long size;

	private String data;

	private String Artist;

	private String mime;

	public String getArtist() {
		return Artist;
	}

	public void setArtist(String artist) {
		Artist = artist;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getDuration() {
		return duration;
	}

	public void setDuration(long duration) {
		this.duration = duration;
	}

	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getMime() {
		return mime;
	}

	public void setMime(String mime) {
		this.mime = mime;
	}

	public MediaItem(String name, long duration, long size, String data,String mime) {
		super();
		this.name = name;
		this.duration = duration;
		this.size = size;
		this.data = data;
		this.mime = mime;
	}
	
	

	public MediaItem(String name, long duration, long size, String data,
			String artist,String mime) {
		super();
		this.name = name;
		this.duration = duration;
		this.size = size;
		this.data = data;
		Artist = artist;
		this.mime = mime;
	}

	@Override
	public String toString() {
		return "MediaItem{" +
				"name='" + name + '\'' +
				", duration=" + duration +
				", size=" + size +
				", data='" + data + '\'' +
				", Artist='" + Artist + '\'' +
				", mime='" + mime + '\'' +
				'}';
	}
}
