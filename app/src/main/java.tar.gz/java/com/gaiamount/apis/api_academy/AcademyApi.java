package com.gaiamount.apis.api_academy;

import com.gaiamount.apis.Configs;

/**
 * Created by yukun on 16-8-4.
 */
public class AcademyApi {
    public static final String ACADEMY = Configs.BASE_URL + "/creator/college/MiXingLight";
    //获取单栏
    public static final String ACADEMY_GETCOLLEGE = ACADEMY + "/getCollege";
    //获取列表
    public static final String ACADEMY_LIST = ACADEMY + "/getCourseList";
    //详情页
    public static final String ACADEMY_DETAIL = ACADEMY + "/details";
    //获取目录
    public static final String ACADEMY_CONTENT = ACADEMY + "/catalog";
    //视频播放
    public static final String ACADEMY_PLAY = ACADEMY + "/watch";
    //获取课表
    public static final String ACADEMY_LESSON = ACADEMY + "/getMySub";
    //开始学习
    public static final String ACADEMY_STARE_STUDY = ACADEMY + "/learn";
}
