package com.gaiamount.apis.api_search;

import com.gaiamount.apis.Configs;
import com.gaiamount.apis.api_creator.GroupApi;

/**
 * Created by haiyang-lu on 16-7-19.
 */
public class SearchApi {
    public static final String SEARCH_WORKS = Configs.BASE_URL+"/works/search";

    public static final String SEARCH_CREATOR = Configs.BASE_URL+"/creator/person/getList";


}
