package com.gaiamount.apis.api_academy;

import android.content.Context;
import android.util.Log;

import com.gaiamount.apis.api_im.ImApi;
import com.gaiamount.util.network.NetworkUtils;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by yukun on 16-8-4.
 */
public class AcademyApiHelper {

    //获取学院首页
    public static void getCollege(JsonHttpResponseHandler jsonHttpResponseHandler){
        Log.d("AcademyActivity", "getcollege:");
        NetworkUtils.get(AcademyApi.ACADEMY_GETCOLLEGE,jsonHttpResponseHandler);
    }
    //mix列表
    public static void getMixList(long cid, int s,int opr,int pi,int t,long uid,Context context, JsonHttpResponseHandler jsonHttpResponseHandler){
        JSONObject jsonObject=new JSONObject();
        try {
            jsonObject.put("cid",cid);
            jsonObject.put("s",s);
            jsonObject.put("opr",opr);
            jsonObject.put("t",t);
            jsonObject.put("pi",pi);
            jsonObject.put("uid",uid);
//            jsonObject.put("channelId",channelId);
            Log.d("MixingLightActivity", jsonObject.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        NetworkUtils.post(context,AcademyApi.ACADEMY_LIST,jsonObject,jsonHttpResponseHandler);
    }
    //学院详情列表uu

    public static void getDetail(long uid, long cid,int t,Context context, JsonHttpResponseHandler jsonHttpResponseHandler){
        JSONObject jsonObject=new JSONObject();
        try {
            jsonObject.put("cid",cid);
            jsonObject.put("t",t);
            jsonObject.put("uid",uid);
            Log.d("AcademyDetailActivity", jsonObject.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        NetworkUtils.post(context,AcademyApi.ACADEMY_DETAIL,jsonObject,jsonHttpResponseHandler);
    }

    //获取目录
    public static void getContent(long cid,Context context, JsonHttpResponseHandler jsonHttpResponseHandler){
        JSONObject jsonObject=new JSONObject();
        try {
            jsonObject.put("cid",cid);
            Log.d("ContentFragment", jsonObject.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        NetworkUtils.post(context,AcademyApi.ACADEMY_CONTENT,jsonObject,jsonHttpResponseHandler);
    }

    //获取视频
    public static void getVideo(long cid,long chapterId,long hid,Context context, JsonHttpResponseHandler jsonHttpResponseHandler){
        JSONObject jsonObject=new JSONObject();
        try {
            jsonObject.put("cid",cid);
            jsonObject.put("chapterId",chapterId);
            jsonObject.put("hid",hid);
            Log.d("AcademyPlayActivity", jsonObject.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        NetworkUtils.post(context,AcademyApi.ACADEMY_PLAY,jsonObject,jsonHttpResponseHandler);
    }
    //获取课表
    public static void getLesson(int  t,int pi,Context context, JsonHttpResponseHandler jsonHttpResponseHandler){
        JSONObject jsonObject=new JSONObject();
        try {
            jsonObject.put("t",t);
            jsonObject.put("pi",pi);
            Log.d("MyLessonActivity", jsonObject.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        NetworkUtils.post(context,AcademyApi.ACADEMY_LESSON,jsonObject,jsonHttpResponseHandler);
    }

    //开始学习
    public static void stareStudy(long cid,Context context, JsonHttpResponseHandler jsonHttpResponseHandler){
        JSONObject jsonObject=new JSONObject();
        try {
            jsonObject.put("cid",cid);
            Log.d("AcademyDetailActivity", jsonObject.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        NetworkUtils.post(context,AcademyApi.ACADEMY_STARE_STUDY,jsonObject,jsonHttpResponseHandler);
    }

}
