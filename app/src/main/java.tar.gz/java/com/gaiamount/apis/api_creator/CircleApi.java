package com.gaiamount.apis.api_creator;

import com.gaiamount.apis.Configs;

/**
 * Created by yukun on 16-7-25.
 */
public class CircleApi {
    //圈子
    public static final String circle_attention = Configs.BASE_URL + "/creator/person/circle";

}
