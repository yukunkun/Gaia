package com.gaiamount.apis.api_creator;

import android.content.Context;
import android.support.annotation.Nullable;

import com.gaiamount.gaia_main.GaiaApp;
import com.gaiamount.util.LogUtil;
import com.gaiamount.util.encrypt.SHA256;
import com.gaiamount.util.network.MJsonHttpResponseHandler;
import com.gaiamount.util.network.NetworkUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by haiyang-lu on 16-6-30.
 * 专辑相关的接口帮助类
 */
public class AlbumApiHelper {
    /**
     * 创建专辑,如果t=1 gid必填；如果pub==0 pwd必填
     *
     * @param name    专辑名称
     * @param bg      封面
     * @param content 专辑简介
     * @param t       专辑类型（0个人1小组)
     * @param gid     如果t为1，此参数不为空
     * @param pub     是否公开
     * @param pwd     密码
     */
    public static void createAlbum(String name, String bg, String content, int t, @Nullable long gid, int pub, String pwd, Context context, MJsonHttpResponseHandler handler) {
        if (name.isEmpty()) {
            GaiaApp.showToast("名称不能为空");
            return;
        }
        if (content.isEmpty()) {
            GaiaApp.showToast("描述不能为空");
            return;
        }
        if (bg.isEmpty()) {
            GaiaApp.showToast("请上传专辑图片");
            return;
        }
        if (pub == 0 && pwd.isEmpty()) {
            GaiaApp.showToast("请输入密码");
            return;
        }
        JSONObject jsonObject = new JSONObject();

        try {
            jsonObject.put("name", name);
            jsonObject.put("bg", bg);
            jsonObject.put("t", t);
            jsonObject.put("content", content);
            if (t == 1) {
                jsonObject.put("gid", gid);
            }
            jsonObject.put("pub", pub);
            if (pub == 0 && pwd != null) {
                jsonObject.put("pwd", SHA256.bin2hex(pwd));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        LogUtil.d(AlbumApiHelper.class, "createAlbum" + jsonObject.toString());

        NetworkUtils.post(context, AlbumApi.CREATE_ALBUM, jsonObject, handler);
    }

    /**
     * 获取专辑创作的作品
     *
     * @param aid     专辑id
     * @param t       小组类型（0个人 1小组)
     * @param c       查询的类别（0 作品 1素材 2剧本 3学院)
     * @param opr     排序类型（0默认 1最新发布 2最多播放 3最多收藏 4最多
     * @param s       查询条件（0全部 1推荐 2 4K 3 可下载 4 免费下载 5 付费下载)
     * @param context
     * @param handler
     */
    public static void searchAlbumWorks(long aid, int t, int c, int opr, int s, int pi, int ps, Context context, MJsonHttpResponseHandler handler) {
        JSONObject jsonObject = new JSONObject();

        try {
            jsonObject.put("aid", aid);
            jsonObject.put("t", t);
            jsonObject.put("c", c);
            jsonObject.put("opr", opr);
            jsonObject.put("s", s);
            jsonObject.put("pi", pi);
            jsonObject.put("ps", ps);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        LogUtil.d(AlbumApiHelper.class, "searchAlbumWorks" + jsonObject.toString());

        NetworkUtils.post(context, AlbumApi.SEARCH_ALBUM_WORKS, jsonObject, handler);
    }

    /**
     * 得到专辑列表
     *对应的javabean为{@link com.gaiamount.module_creator.sub_module_album.AlbumBean}
     * @param gid     小组id
     * @param type    小组类型0 个人 1小组
     * @param opr     排序方式 0默认 1 最新创建 2 最多创作 3 最多浏览
     * @param context
     * @param handler
     */
    public static void getAlbumList(long gid, int type, int opr, Context context, MJsonHttpResponseHandler handler) {
        JSONObject jsonObject = new JSONObject();

        try {
            jsonObject.put("gid", gid);
            jsonObject.put("type", type);
            jsonObject.put("opr", opr);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        LogUtil.d(AlbumApiHelper.class, "getAlbumList" + jsonObject.toString());

        NetworkUtils.post(context, AlbumApi.GET_ALBUM_LIST, jsonObject, handler);
    }

    /**
     * 获取专辑详情
     * @param aid
     * @param pwd
     * @param context
     * @param handler
     */
    public static void getAlbumDetail(long aid, String pwd, Context context, MJsonHttpResponseHandler handler) {
        JSONObject jsonObject = new JSONObject();

        try {
            jsonObject.put("aid", aid);
            if (pwd!=null) {
                jsonObject.put("pwd", SHA256.bin2hex(pwd));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        LogUtil.d(AlbumApiHelper.class, "getAlbumDetail" + jsonObject.toString());

        NetworkUtils.post(context, AlbumApi.DETAILS, jsonObject, handler);
    }

    /**
     * 删除专辑
     * @param aid 专辑id
     * @param context
     * @param handler
     */
    public static void deleteAlbum(long aid, Context context, MJsonHttpResponseHandler handler) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("aid",aid);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        LogUtil.d(AlbumApiHelper.class, "deleteAlbum" + jsonObject.toString());

        NetworkUtils.post(context,AlbumApi.DELETE,jsonObject,handler);
    }

    /**
     * 批量添加创作到一个专辑中
     * @param wids 创作的id数组
     * @param ctype 添加到专辑的视频类型（0作品 1素材 2剧本 3学院)
     * @param aid  专辑id
     * @param context
     * @param handler
     */
    public static void addVideoToAlbum(Long[] wids, long ctype, Long aid, Context context, MJsonHttpResponseHandler handler) {
        JSONObject jsonObject = new JSONObject();
        try {
            JSONArray jsonArray = new JSONArray();
            jsonArray.put(wids[0]);//目前只做单个添加
            jsonObject.put("wids",jsonArray);
            jsonObject.put("c",ctype);
            JSONArray aids = new JSONArray();
            aids.put(aid);
            jsonObject.put("aids",aids);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        LogUtil.d(AlbumApiHelper.class, "addVideoToAlbum" + jsonObject.toString());

        NetworkUtils.post(context,AlbumApi.ADD,jsonObject,handler);
    }

    /**
     * 移除专辑中的某个视频
     * @param id_
     * @param gid
     * @param type
     * @param context
     * @param handler
     */
    public static void removeVideoFromAlbum(long id_, long gid, int type, Context context, MJsonHttpResponseHandler handler) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("id",id_);
            jsonObject.put("gid",gid);
            jsonObject.put("t",type);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        LogUtil.d(AlbumApiHelper.class, "removeVideoFromAlbum" + jsonObject.toString());

        NetworkUtils.post(context,AlbumApi.REMOVE_VIDEO_FROM_ALBUM,jsonObject,handler);
    }
}
